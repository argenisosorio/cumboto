#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from connection import connect_bd
from text import justify_diccionary
from text import file_decode
from text import table_prog_elements_medal

import json,re


def gdata_red(directorio,archivo):
	
	spaces_elements=40
	adjust_col2=40
	adjust_col3=110
	spaces_words=180
			
	def consulta_id_prog():
		query='SELECT programacion.hora, programacion.programa, programacion.dia FROM  programacion.programacion WHERE programacion.src_id = 1'		
		connect=connect_bd()
		cursor = connect.cursor()
		cursor.execute(query)
		connect.commit()
		list_contents = cursor.fetchall()
		lista_d = []
		lista_p=[]
		row1_max=0
		row2_max=0
		
		for element in list_contents:
			row1 = len(str(element[0]))
   			if row1 >= row1_max: 
				row1_max = row1
			row2 = len(str(element[1]))
   			if row2 >= row2_max: 
				row2_max = row2
					
		for text in list_contents:
			elements=str(text[0])+","+str(text[1])
			dia=str(text[2])
			dicts_elements_medal=table_prog_elements_medal(elements,spaces_elements,row1_max,row2_max,adjust_col2,adjust_col3)
			for dict_elements_medal in dicts_elements_medal:
				lista_p.append(dict_elements_medal)
							           
		dic= {"descripcion":lista_p,"dia":dia}
		lista_d.append(dic)
		return lista_d
			
	lista_red= consulta_id_prog()


	mod= 'module("data_red")'
		
	mod1= '[['
		
	mod2= ']]'

	item_red={'item':lista_red}
	channel_red={'rss':[{'channel':item_red}]}
	
	colours={'red': channel_red}
	
	data={"category":colours}
	
	dic= json.dumps(data)
	
	destino_lua=directorio+'/'+archivo
	
	f = open (destino_lua, "w")
		
	f.write(mod)
		
	f.write("FEEDS=")
		
	f.write(mod1)
		
	f.write(dic)
		
	f.write(mod2)
		
	f.close()
	
	encoding='utf-8'
	
	file_decode(encoding,destino_lua)
