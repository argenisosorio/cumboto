from connection import connect_bd
import os


#Funciones para el RSS de Noticias

def rss_src():
	query="SELECT rss_not.url FROM noticias.rss_not"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	url = cursor.fetchall()
	url = '' + ' '.join(', '.join(links) for links in url) + ''   
	list_url= url.split()
	
	return list_url

def id_noticias(url):
	rss= "'" + url + "'" 
	query='SELECT rss_not.id_not FROM noticias.rss_not WHERE url = ' + rss	
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	for link_url in cursor:
		id_url=link_url[0]
	
	return id_url
	
	
def rss_categories ():
	query="SELECT rss_not.id_not FROM noticias.rss_not"
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()	
	categories = 0
	for category in cursor:
		categories += 1
	
	return categories

def save_data_rss(src_id,titulo,enlace,descripcion,fecha,categoria,imagen):
	
	
	save_titulo="'"+titulo+"'"
	save_enlace="'"+enlace+"'"
	save_descripcion="'"+descripcion+"'"
	save_fecha="'"+fecha+"'"
	save_categoria="'"+categoria+"'"
	save_imagen="'"+imagen+"'"
	query="INSERT INTO noticias.noticias (titulo, enlace, descripcion, fecha, src_id, categoria, imagen) VALUES (%s, %s, %s, %s, %i, %s, %s)" %(save_titulo,save_enlace,save_descripcion,save_fecha,src_id,save_categoria,save_imagen)
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()


#Funciones para el RSS de Calendario

def rss_url_cal():
	query="SELECT rss_cal.url FROM calendario.rss_cal"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	url = cursor.fetchall()
	url = '' + ' '.join(', '.join(links) for links in url) + ''   
	list_url= url.split()

	return list_url	

def id_calendary(url):
	rss= "'" + url + "'" 
	query='SELECT rss_cal.id_cal FROM calendario.rss_cal WHERE url = ' + rss	
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	for link_url in cursor:
		id_url=link_url[0]
	
	return id_url

def rss_calendary ():
	query="SELECT rss_cal.id_cal FROM calendario.rss_cal"
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()	
	categories = 0
	for category in cursor:
		categories += 1
	
	return categories

def save_data_rss_calendary(atleta, disciplina, fecha, hora, categoria, dia, src_id):
	atleta="'"+atleta+"'"
	disciplina="'"+disciplina+"'"
	fecha="'"+fecha+"'"
	hora="'"+hora+"'"
	categoria="'"+categoria+"'"
	dia="'"+dia+"'"	
	query="INSERT INTO calendario.calendario (atleta, disciplina, fecha, hora, categoria, dia, src_id) VALUES (%s, %s, %s, %s, %s, %s, %i)" % (atleta, disciplina, fecha, hora, categoria, dia, src_id) 
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()

def restart_id_cal():
	query="ALTER SEQUENCE calendario.calendario_id_seq RESTART WITH 1"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	
def remove_data_cal():
	query="DELETE FROM calendario.calendario"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	restart_id_cal()	

#Funciones para el RSS de programacion 

def rss_url_prog():
	query="SELECT rss_prog.url FROM programacion.rss_prog"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	url = cursor.fetchall()
	url = '' + ' '.join(', '.join(links) for links in url) + ''   
	list_url= url.split()

	return list_url	


def id_prog(url):
	rss= "'" + url + "'" 
	query='SELECT rss_prog.id_prog FROM programacion.rss_prog WHERE url = ' + rss	
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	for link_url in cursor:
		id_url=link_url[0]
	
	return id_url

def rss_prog ():
	query="SELECT rss_prog.id_prog FROM programacion.rss_prog"
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()	
	categories = 0
	for category in cursor:
		categories += 1
	
	return categories

def save_data_rss_prog(hora, programa, fecha, categoria, dia, src_id):
	hora="'"+hora+"'"
	programa="'"+programa+"'"
	fecha="'"+fecha+"'"
	categoria="'"+categoria+"'"
	dia="'"+dia+"'"	
	query="INSERT INTO programacion.programacion (hora, programa, fecha, categoria, dia, src_id) VALUES (%s, %s, %s, %s, %s, %i)" % (hora, programa, fecha, categoria, dia, src_id) 
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	
def restart_id_prog():
	query="ALTER SEQUENCE programacion.programacion_id_seq RESTART WITH 1"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	
def remove_data_prog():
	query="DELETE FROM programacion.programacion"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	restart_id_prog()	

#Funciones para el RSS del medallero

def rss_url_med():
	query="SELECT rss_med.url FROM medallero.rss_med"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	url = cursor.fetchall()
	url = '' + ' '.join(', '.join(links) for links in url) + ''   
	list_url= url.split()

	return list_url[0]	


def id_medallero(url):
	rss= "'" + url + "'" 
	query='SELECT rss_med.id_med FROM medallero.rss_med WHERE url = ' + rss	
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	for link_url in cursor:
		id_url=link_url[0]
	
	return id_url


## Guarda los datos de la primera entrada
def save_data_medallero(medallero):
    connect = connect_bd()
    cursor = connect.cursor()
    cursor.executemany("""INSERT INTO medallero.medallero(posicion,
                              imagen, pais, oro, plata, bronce, total,
                              src_id) VALUES (%(posicion)s, %(imagen)s,
                              %(pais)s, %(oro)s, %(plata)s, %(bronce)s,
                              %(total)s, %(src_id)s)""", medallero)
    connect.commit()
    connect.close()
        
def restart_id_med():
	query="ALTER SEQUENCE medallero.medallero_id_seq RESTART WITH 1"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	
def remove_data_med():
	query="DELETE FROM medallero.medallero"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	restart_id_med()	

#Funciones Generales

def get_id_notice(entry):
	imgfield= "'" + entry + "'" 
	query='SELECT noticias.id FROM noticias.noticias WHERE imagen = ' + imgfield	
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	for id_image in cursor:
		id_entry=id_image[0]
	
	
	return id_entry

def update_image_notice(entry,name_image):
	imgfield= "'" + entry + "'" 
	new_name_image= "'" + name_image + "'" 
	query='UPDATE noticias.noticias SET imagen = '+new_name_image+ ' WHERE imagen = '+ imgfield
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()

def save_image_rss(directory,entry):
	
	extimage='jpg'
	namefile=str(get_id_notice(entry))
	namefile = namefile + '.'+extimage
	path_image=directory +'/'+namefile
	os.system('wget -q '+ entry + ' -O ' + path_image)
	"""os.system('wget -nc '+ entry + ' -O ' + path_image)"""
	update_image_notice(entry,namefile)

def restart_id_notices():
	query="ALTER SEQUENCE noticias.noticias_id_seq RESTART WITH 1"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	
def remove_data_rss():
	query="DELETE FROM noticias.noticias"		
	connect=connect_bd()
	cursor = connect.cursor()
	cursor.execute(query)
	connect.commit()
	restart_id_notices()
