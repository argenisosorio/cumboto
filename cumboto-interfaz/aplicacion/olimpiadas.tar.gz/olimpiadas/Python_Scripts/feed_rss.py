#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import feedparser,re,urllib
from bs4 import BeautifulSoup
from bd_rss import id_noticias
from bd_rss import save_data_rss
from bd_rss import get_id_notice
from bd_rss import save_image_rss
from text   import converted_text
from exceptions import RuntimeError
import requests

def buscar_rss(url):

    def get_image_notice(url):
        link = requests.get(url).content
        soup = BeautifulSoup(link,'lxml')
        images = soup.find_all("img", "wp-post-image")
        if len(images) > 0:
            for image in images:
                link_image=image.get('src')
                link_image=urllib.quote(link_image, safe="%/:=&?~#+!$,;'@()*[]")
                return link_image
        else:
            return '0.jpg'    

    feed = feedparser.parse(url)
    total_notices=len(feed.entries)	

    if total_notices > 0:
		if total_notices > 10:
			notices=10
		else:
			notices=total_notices

		for i in range(notices):
			src_id=id_noticias(url)
			titulo = feed.entries[i].title
			desc = feed["entries"][i]
			descripcion = desc["content"][0].value
			descripcion = converted_text("<.*?> &nbsp; ' ",descripcion)
			categoria = feed.entries[i].category
			enlace = feed.entries[i].link
			fecha = feed.entries[i].updated
			imagen=get_image_notice(enlace)
			
			save_data_rss(src_id,titulo,enlace,descripcion,fecha,categoria,imagen)
			directory='../RSS/media'
			image_default='0.jpg'
			
			if imagen != image_default :
				save_image_rss(directory,imagen)
    else:
		print "No hay información disponible para el enlace ",url,"\nCompruebe su conexión de internet."
		raise RuntimeError("No hay información disponible para el enlace %s" % url)
			

def buscar_categorias(items,categories):
	for category in range(categories):
		link=items[category]
		buscar_rss(link)

