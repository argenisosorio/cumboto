#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from connection import connect_bd
from text import justify_diccionary,file_decode,html_converted
import json,re


def gdata_blue(directorio,archivo):
	
	font_filename = 'fonts/Tiresias-Bold.ttf'
	text_width=300
	font_size_description=14
	font_size_title=16
	encoding='utf-8'

	def consulta_id_4():
		query='SELECT noticias.titulo, noticias.enlace, noticias.descripcion,  noticias.fecha, noticias.categoria,  noticias.imagen FROM  noticias.noticias WHERE noticias.src_id = 1'		
		connect=connect_bd()
		cursor = connect.cursor()
		cursor.execute(query)
		connect.commit()
		list_contents = cursor.fetchall()
		lista = []
		for row in list_contents:
			dic= {"titulo":row[0], "descripcion": row[2], "imagen": row[5] }
			dic['titulo']=justify_diccionary((0, 0), html_converted(dic['titulo']), 
					text_width, font_filename, font_size_title,encoding)
			dic['descripcion']=justify_diccionary((0, 0), html_converted(dic['descripcion']), 
					text_width, font_filename, font_size_description,encoding)
			lista.append(dic)
		return lista
			
	lista_blue= consulta_id_4()


	mod= 'module("data_blue")'
		
	mod1= '[['
		
	mod2= ']]'
	
	item_blue={'item':lista_blue}
	channel_blue={'rss':[{'channel':item_blue}]}

	colours={'blue': channel_blue}
	
	data={"category":colours}
	
	dic= json.dumps(data)
	
	destino_lua=directorio+'/'+archivo

	f = open(destino_lua, "w")
		
	f.write(mod)
		
	f.write("FEEDS=")
		
	f.write(mod1)
		
	f.write(dic)
		
	f.write(mod2)
		
	f.close()
	
	encoding='utf-8'
	
	file_decode(encoding,destino_lua)
