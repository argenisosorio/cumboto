#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import psycopg2, requests,socket


def connect_bd():
	try:
		connect = psycopg2.connect("dbname='olimpiadas' user='administrador' host='localhost' password='123'")
	except:
		print "NO SE HA CONECTADO CON LA BASE DE DATOS"
	
	return connect



