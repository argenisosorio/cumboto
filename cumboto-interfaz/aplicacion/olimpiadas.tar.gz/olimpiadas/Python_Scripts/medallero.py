#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib3
import certifi
from bs4 import BeautifulSoup
from bd_rss import id_medallero,save_data_medallero
from exceptions import RuntimeError


def scraping_medallero(url):
    src_id=id_medallero(url)
    ## Conexion con las rutas donde se hara el rastreo del medallero
    http = urllib3.PoolManager(cert_reqs='CERT_REQUIRED', ca_certs=certifi.where())
    """
       Funcion que permite rastrear atraves de web scraping la url asignada.
       Creado por: Ing. Leonel P. Hernandez M.
       Fecha: 12/07/2017
    """
    ## Conexion con las rutas donde se hara el rastreo del medallero
    medallerowiki = http.request('GET', url)

    ## Obtiene el html de las rutas anteriores
    htmlwiki = medallerowiki.data

    ## Analisa el html
    soupwiki = BeautifulSoup(htmlwiki, "lxml")

    ## Busca la tabla que existe en el html
    wikitable = soupwiki.find('table', {'class': 'wikitable'})
    if len(wikitable) > 0:
        ## Recorre todo las filas de la tabla desde la posicion 1
        medallero = ()
        i = 0
        for row in wikitable.findAll('tr')[1:-1]:
            columnas_w = row.findAll('td')
            rank = columnas_w[0].string
            ## busca la columna con la imagen y extrae el sources
            imagen = row.find('img')['src']
            ## Busca la columna con la etiqueta y extrae el string o text
            pais = row.find('a').string
            oro = columnas_w[2].string
            plata = columnas_w[3].string
            bronce = columnas_w[4].string
            total = columnas_w[5].string
            ##Se guarda en una variable, esto puede ser almacenado en un diccionario\
            ##para posteriomente guardarlo en BD
            i += 1
            if(i<=9):
                if(pais == "Venezuela"):
                    medallero += {'posicion': rank.strip(), 'pais': pais, 'oro': oro,
				'plata': plata, 'bronce': bronce, 'total': total,
				'src_id': src_id, 'imagen': pais+'.jpg'},
                else:
                    medallero += {'posicion': rank.strip(), 'pais': pais, 'oro': oro,
				  'plata': plata, 'bronce': bronce, 'total': total,
				  'src_id': src_id, 'imagen': pais+'.jpg'},
            else:
                if(pais == "Venezuela"):
                    medallero += {'posicion': rank.strip(), 'pais': pais, 'oro': oro,
				  'plata': plata, 'bronce': bronce, 'total': total,
				  'src_id': src_id, 'imagen': pais+'.jpg'},
    else:
        print "No hay información disponible para el enlace ",url,"\nCompruebe su conexión de internet."
        raise RuntimeError("No hay información disponible para el enlace %s" % url)
    
    save_data_medallero(medallero)
