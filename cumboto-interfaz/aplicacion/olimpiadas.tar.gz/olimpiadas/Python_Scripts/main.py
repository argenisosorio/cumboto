#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import shutil, glob, os, sys
from feed_rss import buscar_categorias
from calendary_rss import buscar_items_calendario
from prog_rss import buscar_items_prog
from bd_rss import remove_data_rss,remove_data_cal,remove_data_prog
from bd_rss import rss_src,rss_categories,rss_calendary,rss_url_cal
from bd_rss import rss_prog,rss_url_prog,rss_url_med,remove_data_med
from medallero import scraping_medallero
from data_red import gdata_red
from data_yellow import gdata_yellow
from data_green import gdata_green
from data_blue import gdata_blue
from PIL import Image 


#Esta función se encarga del manejo de los archivos de la carpeta media (copiado y borrado)
def files(instruccion,archivo,origen,destino): 

	if instruccion == "delete" and destino != "":
		if archivo != "" :
			destino_borrado='./'+destino+'/'+archivo
			delete_files = glob.glob(destino_borrado)
		
			for archivo in delete_files:
				os.remove(archivo)
			
	if instruccion == "copy" and archivo != "": 
		if origen != "" and destino != "" :	
			path="./"+ origen + "/" + archivo
			pathd="./" + destino
			shutil.copy(path,pathd)



def redim_images(directorio, extensionimagen): 
    
    busqueda=directorio + "/*."+ extensionimagen
    
    if extensionimagen == "jpg":
		extensionimagen ="jpeg"
		
    
    for ruta in glob.glob(busqueda):
        try:
			im = Image.open(ruta, "r")
			br=im.point(lambda x: x+25)
			br.save(ruta,extensionimagen)
			im = Image.open(ruta, "r")
			dimension= (212, 142)
			res = im.resize((dimension), Image.ANTIALIAS)
			res.save(ruta,extensionimagen)
            
            
            
    	except (IOError, IndexError, TypeError, AttributeError):
            pass
            print "Error al redimensionar la imagen.",ruta
            print "Asignando la imagen por defecto."
            imagen='0.jpg'
            ruta_imagen_defecto=directorio + "/" + imagen
            shutil.copy(ruta_imagen_defecto,ruta)

     

 
if __name__ == '__main__':
 
	
	extensionimagen='jpg'
	directorio_media='../RSS/media'
	archivos_media='*.*'
	borrar= "delete"
	copiar= "copy"
	archivo="0.jpg"
	origen_copiar="image_default"
	archivo_lua_red='data_red.lua'
	archivo_lua='data_green.lua'
	archivo_lua_yellow='data_yellow.lua'
	archivo_lua_blue='data_blue.lua'
	directorio_lua='../RSS/modules/data'
	directorio_xml="XML"
	archivo_calendario="calendario.xml"
	archivo_programacion="programacion.xml"

	#try:	
	files(borrar,archivos_media,"",directorio_media)
	files(copiar,archivo,origen_copiar,directorio_media)
	remove_data_rss()
	remove_data_cal()
	remove_data_prog()
	remove_data_med()

	#Noticias
	url = rss_src()
	categories=rss_categories()

	#Calendario
	url_cal=rss_url_cal()
	calendary_rss=rss_calendary()

	#Programacion
	url_prog=rss_url_prog()
	prog_rss=rss_prog()
	    
	#Medallero
	url_med=rss_url_med()

	print "Obteniendo las noticias del enlace RSS "
	for link in url:
		print link
	buscar_categorias(url,categories)
	redim_images(directorio_media,extensionimagen)
	print "Obteniendo el contenido de calendario del enlace RSS "
	for link in url_cal:
		print link
	buscar_items_calendario(url_cal,calendary_rss,directorio_xml,archivo_calendario)
	print "Obteniendo el contenido de programación del enlaces RSS "
	for link in url_prog:
		print link
	buscar_items_prog(url_prog,prog_rss,directorio_xml,archivo_programacion)
	print "Obteniendo el contenido de medallero de la pagina web \n", url_med
	scraping_medallero(url_med)

	gdata_red(directorio_lua,archivo_lua_red)
	gdata_green(directorio_lua,archivo_lua)
	gdata_blue(directorio_lua,archivo_lua_blue)
	gdata_yellow(directorio_lua,archivo_lua_yellow)
	
	#except:
	#	sys.exit(os.EX_SOFTWARE)
	#sys.exit(os.EX_OK)

