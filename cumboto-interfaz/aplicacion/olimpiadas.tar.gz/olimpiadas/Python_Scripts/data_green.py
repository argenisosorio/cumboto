#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from connection import connect_bd
from text import justify_diccionary
from text import file_decode
from text import table_dicts_medal
import json,re


def gdata_green(directorio,archivo):
	
	spaces_elements=40
	spaces_numers=50
	space_image=10
	spaces_words=180
		

	def consulta_id():
		query='SELECT medallero.posicion, medallero.pais, medallero.oro, medallero.plata, medallero.bronce, medallero.total FROM  medallero.medallero WHERE medallero.src_id = 1'		
		connect=connect_bd()
		cursor = connect.cursor()
		cursor.execute(query)
		connect.commit()
		list_contents = cursor.fetchall()
		lista_d = []
		lista_m=[]
		
		for text in list_contents:
			elements=str(text[0])+","+str(text[1])+","+str(text[2])+","+str(text[3])+","+str(text[4])+","+str(text[5])
			dicts_medal=table_dicts_medal(elements,spaces_elements,space_image,spaces_words,spaces_numers)
			for dict_medal in dicts_medal:
				lista_m.append(dict_medal)  
		      
		dic= {"descripcion":lista_m}
		lista_d.append(dic)
		return lista_d
			
	lista_green= consulta_id() 

	mod= 'module("data_green")'
		
	mod1= '[['
		
	mod2= ']]'
	
	item_green={'item':lista_green}
	channel_green={'rss':[{'channel':item_green}]}
	
	colours={'green': channel_green}
	
	data={"category":colours}
	
	dic= json.dumps(data)
	
	destino_lua=directorio+'/'+archivo
	
	f = open (destino_lua, "w")
		
	f.write(mod)
		
	f.write("FEEDS=")
		
	f.write(mod1)
		
	f.write(dic)
		
	f.write(mod2)
		
	f.close()
	
	encoding='utf-8'
	
	file_decode(encoding,destino_lua)
