#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import feedparser
from xml.dom import minidom
from bd_rss import id_prog,save_data_rss_prog
from text import converted_text,xml_converted
from exceptions import RuntimeError


def buscar_rss(url,directorio_xml,archivo_xml):

    feed = feedparser.parse(url)		

    if len(feed.entries) > 0:
		
		item = feed["entries"][0]
		rss = minidom.parse(xml_converted(directorio_xml,archivo_xml,
			converted_text("<br.*?> </br.*?> <p> </p> &nbsp; ' ",
			item["content"][0].value)))
		nodes = rss.getElementsByTagName('evento')
		events=len(nodes)
	
		if events > 0:

			src_id=id_prog(url)

			categoria = converted_text("<.*?> &nbsp; ' ",
				rss.getElementsByTagName('categoria')[0].firstChild.nodeValue)

			dia = converted_text("<.*?> &nbsp; ' ",
				rss.getElementsByTagName('dia')[0].firstChild.nodeValue)

			fecha = converted_text("<.*?> &nbsp; ' ",
				rss.getElementsByTagName('fecha')[0].firstChild.nodeValue)

		 	for event in range(events):

				programa = converted_text("<.*?> &nbsp; ' ",
					rss.getElementsByTagName('programa')[event].firstChild.nodeValue)

				hora = converted_text("<.*?> &nbsp; ' ",
					rss.getElementsByTagName('hora')[event].firstChild.nodeValue)
		
				save_data_rss_prog(hora, programa, fecha, categoria, dia, src_id)	

		else:
			print "No se encontraron los eventos en la Programación."
		
    else:
		print "No hay información disponible para el enlace ",url,"\nCompruebe su conexión de internet."
		raise RuntimeError("No hay información disponible para el enlace %s" % url)


def buscar_items_prog(items,categories,directorio_xml,archivo_xml):
	for category in range(categories):
		link=items[category]
		buscar_rss(link,directorio_xml,archivo_xml)
