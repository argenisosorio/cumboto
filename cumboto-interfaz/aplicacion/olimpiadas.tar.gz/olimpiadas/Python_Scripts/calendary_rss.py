#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import feedparser
from xml.dom import minidom
from bd_rss import id_calendary,save_data_rss_calendary
from text import converted_text,xml_converted
from exceptions import RuntimeError


def buscar_rss(url,directorio_xml,archivo_xml):

    feed = feedparser.parse(url)		

    if len(feed.entries) > 0:
		
		item = feed["entries"][0]
		calendario = minidom.parse(xml_converted(directorio_xml,archivo_xml,
						converted_text("<br.*?> </br.*?> <p.*?> </p.*?> &nbsp; ' ",
						item["content"][0].value)))
		nodes = calendario.getElementsByTagName('evento')
		events=len(nodes)
	
		if events > 0:

			src_id=id_calendary(url)

			categoria = converted_text("<.*?> &nbsp; ' ",
						calendario.getElementsByTagName('categoria')[0].firstChild.nodeValue)

			dia = converted_text("<.*?> &nbsp; ' ",
				calendario.getElementsByTagName('dia')[0].firstChild.nodeValue)

			fecha = converted_text("<.*?> &nbsp; ' ",
				calendario.getElementsByTagName('fecha')[0].firstChild.nodeValue)

		 	for event in range(events):

				atleta = converted_text("<.*?> &nbsp; ' ",
					calendario.getElementsByTagName('nombre')[event].firstChild.nodeValue)

				disciplina = converted_text("<.*?> &nbsp; ' ",
					calendario.getElementsByTagName('disciplina')[event].firstChild.nodeValue)

				hora = converted_text("<.*?> &nbsp; ' ",
					calendario.getElementsByTagName('hora')[event].firstChild.nodeValue)
		
				save_data_rss_calendary(atleta, disciplina, fecha, hora, categoria, dia, src_id)	

		else:
			print "No se encontraron los eventos en el Calendario."
		
    else:
		print "No hay información disponible para el enlace ",url,"\nCompruebe su conexión de internet."
		raise RuntimeError("No hay información disponible para el enlace %s" % url)


def buscar_items_calendario(items,categories,directorio_xml,archivo_xml):
	for category in range(categories):
		link=items[category]
		buscar_rss(link,directorio_xml,archivo_xml)
