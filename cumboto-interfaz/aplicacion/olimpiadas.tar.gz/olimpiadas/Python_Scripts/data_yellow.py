#!/usr/bin/env python
# -*- coding: UTF-8 -*-
from connection import connect_bd
from text import justify_diccionary
from text import file_decode
from text import table_cal_elements_medal

import json,re


def gdata_yellow(directorio,archivo):

	spaces_elements=0
	adjust_col2=170
	adjust_col3=197
	adjust_col4=0
        spaces_words=180
	
	def consulta_id():
		query='SELECT calendario.atleta, calendario.disciplina,  calendario.hora, calendario.dia FROM  calendario.calendario WHERE calendario.src_id = 1'		
		connect=connect_bd()
		cursor = connect.cursor()
		cursor.execute(query)
		connect.commit()
		list_contents = cursor.fetchall()
		lista_d = []
		lista_c=[]
		row1_max=0
		row2_max=0
		row3_max=0
		row4_max=0
		
		
		for element in list_contents:
			row1 = len(str(element[0]))
   			if row1 >= row1_max: 
				row1_max = row1
			row2 = len(str(element[1]))
   			if row2 >= row2_max: 
				row2_max = row2
			row3 = len(str(element[2]))
   			if row3 >= row3_max: 
				row3_max = row3
		for text in list_contents:
			elements=str(text[0])+","+str(text[1])+","+str(text[2])
			dia=str(text[3])
			dicts_elements_medal=table_cal_elements_medal(elements,spaces_elements,row1_max,row2_max,row3_max,row4_max,adjust_col2,adjust_col3,adjust_col4)
			for dict_elements_medal in dicts_elements_medal:
				lista_c.append(dict_elements_medal)  
	 	   
		dic= {"descripcion":lista_c,"dia":dia}
		lista_d.append(dic)
		return lista_d
			
	lista_yellow= consulta_id() 

	mod= 'module("data_yellow")'
		
	mod1= '[['
		
	mod2= ']]'
	
	
	item_yellow={'item':lista_yellow}
	channel_yellow={'rss':[{'channel':item_yellow}]}
	
	colours={'yellow': channel_yellow}
	
	data={"category":colours}
	
	dic= json.dumps(data)
	
	destino_lua=directorio+'/'+archivo
	
	f = open (destino_lua, "w")
		
	f.write(mod)
		
	f.write("FEEDS=")
		
	f.write(mod1)
		
	f.write(dic)
		
	f.write(mod2)
		
	f.close()
	
	encoding='utf-8'
	
	file_decode(encoding,destino_lua)
archivo_lua_yellow='data_yellow.lua'
directorio_lua='../RSS/modules/data'
gdata_yellow(directorio_lua,archivo_lua_yellow)
