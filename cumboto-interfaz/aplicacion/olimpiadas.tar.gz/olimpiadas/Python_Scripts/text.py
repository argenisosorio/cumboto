#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import re, random, json 
from PIL import ImageFont

def converted_text(tags,text_converted):
	list_tags= tags.split()
	for tag in range (len(list_tags)):
		replace=r""+list_tags[tag]+""
		text_converted=re.sub(replace,'',text_converted)
	return text_converted

def justify_diccionary((x, y), text, text_width, font_filename, font_size, encoding):
   
       
    if isinstance(text, str):
        text = text.decode(encoding)
   

    def get_text_size(font_filename, font_size, text):
        font = ImageFont.truetype(font_filename, font_size)
        return font.getsize(text)

        
    def get_font_size(text, font, max_width=None, max_height=None):
        if max_width is None and max_height is None:
            raise ValueError('You need to pass max_width or max_height')
        font_size = 1
        text_size = get_text_size(font, font_size, text)
        if (max_width is not None and text_size[0] > max_width) or \
           (max_height is not None and text_size[1] > max_height):
            raise ValueError("Text can't be filled in only (%dpx, %dpx)" % \
                    text_size)
        while True:
            if (max_width is not None and text_size[0] >= max_width) or \
               (max_height is not None and text_size[1] >= max_height):
                return font_size - 1
            font_size += 1
            text_size = get_text_size(font, font_size, text)

    def justify_word ((x, y), text, font_filename, font_size, max_width=None, max_height=None):
	if font_size == 'fill' and \
           (max_width is not None or max_height is not None):
            font_size = get_font_size(text, font_filename, max_width,
                                           max_height)
        text_size = get_text_size(font_filename, font_size, text)
        font = ImageFont.truetype(font_filename, font_size)
        y=16
        dictionary_justify_words={"row":x,"col":y,"words":text}
	return dictionary_justify_words

    
    def justify_words_lines((x, y), text, text_width, font_filename,font_size, justify_last_line=False):
	place='justify'        
	lines = []
        line = []
	list_dictionary_justify_words=[]
        words = text.split()
        
        for word in words:
            
            if word == "|": 
                lines.append(line)
                line = []
                continue

            if word == "||": 
                lines.append(line)
                lines.append(" ")
                line = []
                continue

            
            new_line = ' '.join(line + [word])
            size = get_text_size(font_filename, font_size, new_line)
            text_height = size[1]
            if size[0] <= text_width:
                line.append(word)
            else:
                lines.append(line)
                line = [word]
        
        if line:
            lines.append(line)
        lines = [' '.join(line) for line in lines if line]
        height = y
        for index, line in enumerate(lines):
            height += text_height
            if place == 'justify':
                words = line.split()
                
                if len(words) == 0:
                    words = [" "]
                    
                if (index == len(lines) - 1 and not justify_last_line) or \
                   len(words) == 1:
                    list_dictionary_justify_words.append(justify_word((x, height), line, font_filename, font_size))
                    continue
                line_without_spaces = ''.join(words)
                total_size = get_text_size(font_filename, font_size,line_without_spaces)
                space_width = (text_width - total_size[0]) / (len(words) - 1.0)
                start_x = x
                
		
		for word in words[:-1]:
                    list_dictionary_justify_words.append(justify_word((start_x, height), word, font_filename,font_size))
                    word_size = get_text_size(font_filename, font_size,word)
                    start_x += word_size[0] + space_width

                last_word_size = get_text_size(font_filename, font_size,words[-1])
                last_word_x = x + text_width - last_word_size[0]
                list_dictionary_justify_words.append(justify_word((last_word_x, height), words[-1], font_filename,font_size))

	return list_dictionary_justify_words

    
    return justify_words_lines((x, y), text, text_width, font_filename, font_size)	

def table_space_words(words,spe):
	list_words=words.split(",")
	values=''
	for word in range (len(list_words)-1):
		values+=list_words[word]
		for sp in range (spe):
			space=" "
			values+=space
				
	values+=list_words[-1]			
	return values  

def table_space_medal(value_max,words,spe):
	list_words=words.split(",")
	values=' '
	spaces=0
	for word in range (len(list_words)-1):
		values+=list_words[word]
		
		if word == 0 or word == 2 or word == 3 or word == 4 or word == 5:
			value=len(list_words[word])
			if value == 1:
				spp=2
		
				for sp in range (spp):
					space=' '
					values+=space
			if value == 2:
				spp=1
		
				for sp in range (spp):
					space=''
					values+=space		
			
		if word == 1:
			value=len(list_words[word])
			if value_max >= value:
				spaces = value_max - value
				spc=spaces
		
				for sp in range (spc):
					space=' '
					values+=space

		
			
		for sp in range (spe):
			space=" "
			values+=space
			
	values+=list_words[-1]			
	return values 

def table_dicts_medal(words,spe,spimg,spws,spn):
	list_dicts_words=[]
	dict_words={}
	list_words=words.split(",")
	col=16
	init=0
	row=0
	add=0
		
	for word in range (len(list_words)):
		if word == 0:
			value=len(list_words[word])
			dict_words={"row":init,"col":col,"words":list_words[word]}
			list_dicts_words.append(dict_words)
			if value == 1:
				spp=2
				row=spp+row+spe+spimg		
				
			if value == 2:
				spp=1
				row=spp+row+spe+spimg
									
		if word == 1:
			value=len(list_words[word])
			if spws > value:
				add = spws - value
				
			dict_words={"row":row,"col":col,"words":list_words[word]}
			list_dicts_words.append(dict_words)
			row=spe+add+value
		
		if word == 2 or word == 3 or word == 4:
			value=len(list_words[word])
			dict_words={"row":row,"col":col,"words":list_words[word]}
			list_dicts_words.append(dict_words)	
					
			row=row+spn			
			if value == 1:
				spp=2
				row=spp+row		
				
			if value == 2:
				spp=1
				row=spp+row
		if word == 5:
			dict_words={"row":row,"col":col,"words":list_words[word]}
			list_dicts_words.append(dict_words)	
							
	return list_dicts_words


def table_cal_elements_medal(elements,spe,spr1,spr2,spr3,spr4,col1,col2,col3):
	list_dicts_elements=[]
	dict_elements={}
	list_elements=elements.split(",")
	values=0
	col=16
	row=0
	init=0
	for element in range (len(list_elements)):
		
		if element == 0:
			value=len(list_elements[element])
			dict_elements={"row":init,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)
			row=spe+spr1+col1
									
		if element == 1:
			dict_elements={"row":row,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)
			row=spe+row+spr2+col2
			
		if element == 2:
			dict_elements={"row":row,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)
			row=row+spr3+col3
			
		if element == 3:
			value=len(list_elements[element])
			if value < spr4:
				spp=10
				row=spp+row
			dict_elements={"row":row,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)	
								
	return list_dicts_elements

def table_prog_elements_medal(elements,spe,spr1,spr2,col1,col2):
	list_dicts_elements=[]
	dict_elements={}
	list_elements=elements.split(",")
	values=0
	col=16
	row=0
	init=0
	for element in range (len(list_elements)):
		
		if element == 0:
			value=len(list_elements[element])
			dict_elements={"row":init,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)
			row=spe+spr1+col1
								
		if element == 1:
			dict_elements={"row":row,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)
			row=row+spr2+col2
					
		if element == 2:
			value=len(list_elements[element])
			if value < spr3:
				spp=10
				row=spp+row
			dict_elements={"row":row,"col":col,"words":list_elements[element]}
			list_dicts_elements.append(dict_elements)	
									
	return list_dicts_elements


def replace_value(data, sequences):
	for i, j in sequences.iteritems():
		data = data.replace(i, j)
	return data

        
def file_decode(encoding,filename):
						
	opendata = open(filename, 'r').read() 	
	sequences = {'\\n':'', '\\"':'|"','\t':'|t','[video]':'','[audio]':''}
	data_encode = replace_value(opendata, sequences)
	data_converted = data_encode.decode('unicode-escape')
	savedata = open(filename, 'w')
	savedata.write(data_converted.encode(encoding))	
	savedata.close()
	sequences_inverse = {'|"':'\\"','|t':'\t'}
	savedata_inverse = open(filename, 'r').read()
	data_decode = replace_value(savedata_inverse, sequences_inverse)
	savedata_inverse = open(filename, 'w')
	savedata_inverse.write(data_decode)
	savedata_inverse.close()


def xml_converted(directory_xml,filename_xml,xml_items):
	data_xml=directory_xml+'/'+filename_xml
	xml = open (data_xml, "w")
	encoding="UTF-8"
	header='<?xml version="1.0" encoding="'+encoding+'" ?>'
	xml.write(header)
	xml.write(xml_items.encode(encoding))
	xml.close()
	return data_xml

def html_converted(text):
	html_characters = {
        "&amp;"   : "&",
        "&quot;"  : '"',
        "&apos;"  : "'",
		"&#8216;" : "'",
		"&#8217;" : "'",
        "&gt;"    : ">",
        "&lt;"    : "<",
		"&#8218;" : ',',
		"&#8220;" : '"',
        "&#8221;" : '"',
		"&#8222;" : ',',
        }
 	return replace_value(text, html_characters)
