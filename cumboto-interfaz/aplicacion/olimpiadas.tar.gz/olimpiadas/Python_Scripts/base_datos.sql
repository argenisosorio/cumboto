--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: calendario; Type: SCHEMA; Schema: -; Owner: administrador
--

CREATE SCHEMA calendario;


ALTER SCHEMA calendario OWNER TO administrador;

--
-- Name: medallero; Type: SCHEMA; Schema: -; Owner: administrador
--

CREATE SCHEMA medallero;


ALTER SCHEMA medallero OWNER TO administrador;

--
-- Name: noticias; Type: SCHEMA; Schema: -; Owner: administrador
--

CREATE SCHEMA noticias;


ALTER SCHEMA noticias OWNER TO administrador;

--
-- Name: programacion; Type: SCHEMA; Schema: -; Owner: administrador
--

CREATE SCHEMA programacion;


ALTER SCHEMA programacion OWNER TO administrador;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = calendario, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: calendario; Type: TABLE; Schema: calendario; Owner: administrador; Tablespace: 
--

CREATE TABLE calendario (
    id integer NOT NULL,
    atleta text,
    disciplina text,
    fecha text,
    hora text,
    src_id integer,
    categoria text,
    dia text
);


ALTER TABLE calendario.calendario OWNER TO administrador;

--
-- Name: calendario_id_seq; Type: SEQUENCE; Schema: calendario; Owner: administrador
--

CREATE SEQUENCE calendario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE calendario.calendario_id_seq OWNER TO administrador;

--
-- Name: calendario_id_seq; Type: SEQUENCE OWNED BY; Schema: calendario; Owner: administrador
--

ALTER SEQUENCE calendario_id_seq OWNED BY calendario.id;


--
-- Name: rss_cal; Type: TABLE; Schema: calendario; Owner: administrador; Tablespace: 
--

CREATE TABLE rss_cal (
    id_cal integer NOT NULL,
    url text,
    titulo text,
    enlace text
);


ALTER TABLE calendario.rss_cal OWNER TO administrador;

--
-- Name: rss_cal_id_cal_seq; Type: SEQUENCE; Schema: calendario; Owner: administrador
--

CREATE SEQUENCE rss_cal_id_cal_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE calendario.rss_cal_id_cal_seq OWNER TO administrador;

--
-- Name: rss_cal_id_cal_seq; Type: SEQUENCE OWNED BY; Schema: calendario; Owner: administrador
--

ALTER SEQUENCE rss_cal_id_cal_seq OWNED BY rss_cal.id_cal;


SET search_path = medallero, pg_catalog;

--
-- Name: medallero; Type: TABLE; Schema: medallero; Owner: administrador; Tablespace: 
--

CREATE TABLE medallero (
    id integer NOT NULL,
    posicion text,
    pais text,
    oro text,
    plata text,
    bronce text,
    total text,
    src_id integer,
    imagen text
);


ALTER TABLE medallero.medallero OWNER TO administrador;

--
-- Name: medallero_id_seq; Type: SEQUENCE; Schema: medallero; Owner: administrador
--

CREATE SEQUENCE medallero_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE medallero.medallero_id_seq OWNER TO administrador;

--
-- Name: medallero_id_seq; Type: SEQUENCE OWNED BY; Schema: medallero; Owner: administrador
--

ALTER SEQUENCE medallero_id_seq OWNED BY medallero.id;


--
-- Name: rss_med; Type: TABLE; Schema: medallero; Owner: administrador; Tablespace: 
--

CREATE TABLE rss_med (
    id_med integer NOT NULL,
    url text,
    titulo text,
    enlace text
);


ALTER TABLE medallero.rss_med OWNER TO administrador;

--
-- Name: rss_med_id_med_seq; Type: SEQUENCE; Schema: medallero; Owner: administrador
--

CREATE SEQUENCE rss_med_id_med_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE medallero.rss_med_id_med_seq OWNER TO administrador;

--
-- Name: rss_med_id_med_seq; Type: SEQUENCE OWNED BY; Schema: medallero; Owner: administrador
--

ALTER SEQUENCE rss_med_id_med_seq OWNED BY rss_med.id_med;


SET search_path = noticias, pg_catalog;

--
-- Name: noticias; Type: TABLE; Schema: noticias; Owner: administrador; Tablespace: 
--

CREATE TABLE noticias (
    id integer NOT NULL,
    titulo text,
    enlace text,
    descripcion text,
    fecha text,
    imagen text,
    src_id integer,
    categoria text
);


ALTER TABLE noticias.noticias OWNER TO administrador;

--
-- Name: noticias_id_seq; Type: SEQUENCE; Schema: noticias; Owner: administrador
--

CREATE SEQUENCE noticias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE noticias.noticias_id_seq OWNER TO administrador;

--
-- Name: noticias_id_seq; Type: SEQUENCE OWNED BY; Schema: noticias; Owner: administrador
--

ALTER SEQUENCE noticias_id_seq OWNED BY noticias.id;


--
-- Name: rss_not; Type: TABLE; Schema: noticias; Owner: administrador; Tablespace: 
--

CREATE TABLE rss_not (
    id_not integer NOT NULL,
    url text,
    titulo text,
    enlace text
);


ALTER TABLE noticias.rss_not OWNER TO administrador;

--
-- Name: rss_noticias_id_not_seq; Type: SEQUENCE; Schema: noticias; Owner: administrador
--

CREATE SEQUENCE rss_noticias_id_not_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE noticias.rss_noticias_id_not_seq OWNER TO administrador;

--
-- Name: rss_noticias_id_not_seq; Type: SEQUENCE OWNED BY; Schema: noticias; Owner: administrador
--

ALTER SEQUENCE rss_noticias_id_not_seq OWNED BY rss_not.id_not;


SET search_path = programacion, pg_catalog;

--
-- Name: programacion; Type: TABLE; Schema: programacion; Owner: administrador; Tablespace: 
--

CREATE TABLE programacion (
    id integer NOT NULL,
    programa text,
    hora text,
    src_id integer,
    categoria text,
    fecha text,
    sinopsis text,
    dia text
);


ALTER TABLE programacion.programacion OWNER TO administrador;

--
-- Name: programacion_id_seq; Type: SEQUENCE; Schema: programacion; Owner: administrador
--

CREATE SEQUENCE programacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE programacion.programacion_id_seq OWNER TO administrador;

--
-- Name: programacion_id_seq; Type: SEQUENCE OWNED BY; Schema: programacion; Owner: administrador
--

ALTER SEQUENCE programacion_id_seq OWNED BY programacion.id;


--
-- Name: rss_prog; Type: TABLE; Schema: programacion; Owner: administrador; Tablespace: 
--

CREATE TABLE rss_prog (
    id_prog integer NOT NULL,
    url text,
    titulo text,
    enlace text
);


ALTER TABLE programacion.rss_prog OWNER TO administrador;

--
-- Name: rss_prog_id_prog_seq; Type: SEQUENCE; Schema: programacion; Owner: administrador
--

CREATE SEQUENCE rss_prog_id_prog_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE programacion.rss_prog_id_prog_seq OWNER TO administrador;

--
-- Name: rss_prog_id_prog_seq; Type: SEQUENCE OWNED BY; Schema: programacion; Owner: administrador
--

ALTER SEQUENCE rss_prog_id_prog_seq OWNED BY rss_prog.id_prog;


SET search_path = calendario, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: calendario; Owner: administrador
--

ALTER TABLE ONLY calendario ALTER COLUMN id SET DEFAULT nextval('calendario_id_seq'::regclass);


--
-- Name: id_cal; Type: DEFAULT; Schema: calendario; Owner: administrador
--

ALTER TABLE ONLY rss_cal ALTER COLUMN id_cal SET DEFAULT nextval('rss_cal_id_cal_seq'::regclass);


SET search_path = medallero, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: medallero; Owner: administrador
--

ALTER TABLE ONLY medallero ALTER COLUMN id SET DEFAULT nextval('medallero_id_seq'::regclass);


--
-- Name: id_med; Type: DEFAULT; Schema: medallero; Owner: administrador
--

ALTER TABLE ONLY rss_med ALTER COLUMN id_med SET DEFAULT nextval('rss_med_id_med_seq'::regclass);


SET search_path = noticias, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: noticias; Owner: administrador
--

ALTER TABLE ONLY noticias ALTER COLUMN id SET DEFAULT nextval('noticias_id_seq'::regclass);


--
-- Name: id_not; Type: DEFAULT; Schema: noticias; Owner: administrador
--

ALTER TABLE ONLY rss_not ALTER COLUMN id_not SET DEFAULT nextval('rss_noticias_id_not_seq'::regclass);


SET search_path = programacion, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: programacion; Owner: administrador
--

ALTER TABLE ONLY programacion ALTER COLUMN id SET DEFAULT nextval('programacion_id_seq'::regclass);


--
-- Name: id_prog; Type: DEFAULT; Schema: programacion; Owner: administrador
--

ALTER TABLE ONLY rss_prog ALTER COLUMN id_prog SET DEFAULT nextval('rss_prog_id_prog_seq'::regclass);


SET search_path = calendario, pg_catalog;

--
-- Data for Name: calendario; Type: TABLE DATA; Schema: calendario; Owner: administrador
--

COPY calendario (id, atleta, disciplina, fecha, hora, src_id, categoria, dia) FROM stdin;
1	Paola Pérez	Natación	22-07-16	07:35 am	1	Calendario	Viernes
2	Rubén Limardo	Esgrima	22-07-16	08:35 am	1	Calendario	Viernes
3	Albert Subirats	Natación Estilo Mariposa	22-07-16	11:35 am	1	Calendario	Viernes
4	Rubén Limardo	Esgrima	22-07-16	02:00 pm	1	Calendario	Viernes
5	Albert Subirats	Natación Estilo Mariposa	22-07-16	03:30 pm	1	Calendario	Viernes
6	Rubén Limardo	Esgrima	22-07-16	04:00 pm	1	Calendario	Viernes
7	Paola Pérez	Natación Estilo Libre	22-07-16	05:00 pm	1	Calendario	Viernes
8	Rubén Limardo	Esgrima	22-07-16	06:30 pm	1	Calendario	Viernes
9	Paola Pérez	Natación Estilo Libre	22-07-16	07:00 pm	1	Calendario	Viernes
\.


--
-- Name: calendario_id_seq; Type: SEQUENCE SET; Schema: calendario; Owner: administrador
--

SELECT pg_catalog.setval('calendario_id_seq', 9, true);


--
-- Data for Name: rss_cal; Type: TABLE DATA; Schema: calendario; Owner: administrador
--

COPY rss_cal (id_cal, url, titulo, enlace) FROM stdin;
1	http://www.tves.gob.ve/olimpiadas2016/?cat=4&feed=rss2	Calendario	http://www.tves.gob.ve/olimpiadas2016/
\.


--
-- Name: rss_cal_id_cal_seq; Type: SEQUENCE SET; Schema: calendario; Owner: administrador
--

SELECT pg_catalog.setval('rss_cal_id_cal_seq', 1, true);


SET search_path = medallero, pg_catalog;

--
-- Data for Name: medallero; Type: TABLE DATA; Schema: medallero; Owner: administrador
--

COPY medallero (id, posicion, pais, oro, plata, bronce, total, src_id, imagen) FROM stdin;
1	1	Estados Unidos	46	29	29	104	1	Estados Unidos.jpg
2	2	China	38	27	23	88	1	China.jpg
3	3	Reino Unido	29	17	19	65	1	Reino Unido.jpg
4	4	Rusia	24	26	32	82	1	Rusia.jpg
5	5	Corea del Sur	13	8	7	28	1	Corea del Sur.jpg
6	6	Alemania	11	19	14	44	1	Alemania.jpg
7	7	Francia	11	11	12	34	1	Francia.jpg
8	8	Italia	8	9	11	28	1	Italia.jpg
9	9	Hungría	8	4	6	18	1	Hungría.jpg
10	50	Venezuela	1	0	0	1	1	Venezuela.jpg
\.


--
-- Name: medallero_id_seq; Type: SEQUENCE SET; Schema: medallero; Owner: administrador
--

SELECT pg_catalog.setval('medallero_id_seq', 10, true);


--
-- Data for Name: rss_med; Type: TABLE DATA; Schema: medallero; Owner: administrador
--

COPY rss_med (id_med, url, titulo, enlace) FROM stdin;
1	https://es.wikipedia.org/wiki/Anexo:Medallero_de_los_Juegos_Ol%C3%ADmpicos_de_Londres_2012	Medallero	http://www.tves.gob.ve/olimpiadas2016/
\.


--
-- Name: rss_med_id_med_seq; Type: SEQUENCE SET; Schema: medallero; Owner: administrador
--

SELECT pg_catalog.setval('rss_med_id_med_seq', 1, true);


SET search_path = noticias, pg_catalog;

--
-- Data for Name: noticias; Type: TABLE DATA; Schema: noticias; Owner: administrador
--

COPY noticias (id, titulo, enlace, descripcion, fecha, imagen, src_id, categoria) FROM stdin;
8	Caraqueños disfrutaron de la antorcha olímpica	http://www.tves.gob.ve/olimpiadas2016/?p=235	Miles de Caraqueñas y Caraqueños tuvieron la dicha de disfrutar al máximo la antorcha olímpica, en la plaza las Tres Gracias de Caracas, gracias al Comité Olímpico Venezolano (COV) que busca acercarse cada vez más al pueblo.\nLas y los habitantes de la capital, desde tempranas horas del día, aprovecharon los espacios de la cliclovía de los Símbolos, para fotografiarse con uno de los objetos más emblemáticos del movimiento olímpico en el planeta, la antorcha.\n“Estoy sumamente contento con la aceptación y participación del pueblo venezolano con el movimiento olímpico. Este es un trabajo al que nos hemos dedicado en los últimos años y hoy vemos importantes resultados por parte de la población en general”, declaró Eduardo Álvarez, presidente del COV.\nEl COV se ha volcado a las calles, colegios, liceos, universidades y comunidades del país, con la finalidad de dar a conocer los valores olímpicos y sobre todo para familiarizar a la población con este movimiento.\n“Esto ha sido increíble, hace 10 años nadie conocía el olimpismo y todo lo que trae con sigo. Ahora la gente tiene la facilidad de tomarse una foto con la réplica de la antorcha y hasta se ir al museo para conocer de la historia de nuestros atletas olímpicos”, agregó Álvarez.\nDebido a los problemas económicos que azotan a la nación, en el COV aseguran que se han sentado a planificar muchos proyectos que se elaboran a bajos costos.\n“Estamos en constante trabajo, no podemos quedarnos cruzados de brazos, por ello hemos inventado una serie de eventos que nos acercan cada vez más a las comunidades y que son de muy bajo costo”, sostuvo Álvarez.\nAparte de la antorcha y caravanas, el COV creó los aros funcionales, los cuales son los mismos que integran su bandera y que son utilizados por instructores para hacer sudar a quienes participan en las jornadas.\nYa esta modalidad ha visitado escuelas públicas y privadas y según Álvarez este proyecto será presentado al Comité Olímpico Internacional (COI) para que sea implementado durante los juegos.\n“Tenemos previsto presentarle este proyecto al COI en Río. Queremos que el movimiento olímpico siga tomando cada vez más fuerza en el mundo”, precisó Álvarez.\nEsté próximo sábado se congregarán en la parroquia 23 de Enero, donde compartirán con las y los habitantes de la combativa comunidad caraqueña.\nLA AVANZADA\nLa delegación criolla tendrá su primera avanzada el día de mañana, cuando las personas que tendrán la responsabilidad de recibir a los atletas, viajen para recibir las instalaciones por parte del comité organizador de los juegos.\n“Recordemos que muchos de nuestros atletas están en el extranjero cumpliendo con su fase de preparación, por lo que llegarán directamente a Río. El trabajo de estas personas es muy importante debido a que ellos serán los encargados de darle la bienvenida a sus compatriotas”, manifestó Álvarez.\nUna vez que el comité organizador haga entrega de la Villa Olímpica el próximo 24 de julio, se dará el visto bueno y se procederá a darle la entrada a los atletas venezolanos, que durante 15 días compartirán en igualdad de condiciones con los mejores del planeta.\nAl respecto Álvarez explicó: “Todos los reportes que hemos recibidos indican que todo está listo esperando a que lleguen los atletas. Creo que estos serán unos grandes juegos para nosotros, estamos en nuestro patio y vamos a dar una gran batalla”.\nVía Correo del Orinoco	Mon, 18 Jul 2016 17:21:31 +0000	8.jpg	1	Noticias
3	Tves: Canal Oficial de los Juegos Olímpicos Río 2016	http://www.tves.gob.ve/olimpiadas2016/?p=251	La bandera de la Televisora Venezolana Social (TVES) es el deporte, llevando como estandarte el privilegio de ser el canal de la Generación de Oro. En este año TVES ha traído a sus hogares una serie de eventos deportivos, mostrando el apoyo incansable hacia nuestros atletas, equipos y delegaciones.\nLa Liga Venezolana de Béisbol Profesional, la Serie del Caribe, la Copa América Centenario, los Juegos Interescuelas Militares, la Liga Nacional Bolivariana de Béisbol, el Sudamericano de Baloncesto Caracas, sumando las distintas coberturas de eventos a través de sus programas Café Deportivo, Motores En Vivo y la sección deportiva en Te ves en la mañana, son el abreboca para la cita más importante del 2016 en Río de Janeiro.\nComo Canal Oficial de los Juegos Olímpicos Río 2016, TVES ofrece una cobertura completa y exclusiva con más de 12 horas de transmisión EN DIRECTO de manera diaria.\nMás de 10.500 atletas, 206 comités olímpicos nacionales y un total de 306 eventos en 28 disciplinas deportivas son las que a partir del 5 hasta el 21 de agosto darán vida a la fiesta en el país brasileño. Con el lema ‘Un Mundo Nuevo’ el deporte será la unión de todo el globo terráqueo en este acontecimiento.\nLa elección de Río marcó la primera vez como designación de dicha ciudad, sede de unos Juegos Olímpicos. Agregando a su vez, la primera participación de un país sudamericano como organizador y la segunda en una nación de Latinoamérica (la primera fue México 1968).\nCon el mejor equipo de narradores, comentaristas, analistas deportivos, invitados especiales y enviados desde el lugar de los hechos, TVES se convertirá en vitrina exclusiva en señal abierta a través de todo el territorio nacional y Televisión Digital Abierta (TDA), cubriendo cada participación de los 86 deportistas venezolanos presentes en la magna cita del deporte mundial, los Juegos Olímpicos Río 2016.\nFuente: Alan Muro / Prensa Tves	Tue, 19 Jul 2016 22:33:03 +0000	3.jpg	1	Noticias
9	Ruben Limardo: ‘Estamos preparados para asumir nuestros terceros Juegos Olímpicos’	http://www.tves.gob.ve/olimpiadas2016/?p=229	El esgrimista venezolano Rubén Limardo busca revalidar su medalla de oro con la espada.\nEl espadista ganador de Oro en Londres, buscará traer la medalla de oro, a tierra venezolana y es por eso que se le ha visto prepararse con gran esfuerzo y entusiasmo.\nA través de su cuenta de Twitter, el esgrimista a mencionado su emoción y sus ganas de seguir luchando en el deporte y asegura que regresará de Río bendecido.\nLa Televisora Venezolana Social (TVES), será el canal oficial que trasmita en señal abierta para todo el territorio venezolano, el evento deportivo más importante del mundo, los Juegos Olímpicos Río 2016.\n\n\n#amenosdeunmes estamos preparados para asumir nuestros terceros Juegos Olímpicos VENEZUELA!! @rio2016_es pic.twitter.com/83aWwbSMNL\n— Ruben Limardo Gascon (@rubenoszki) 10 de julio de 2016\n\n\nFaltan 24 días para el inicio de los JJOO #Rio2016 , 86 héroes y heroínas representarán a #Venezuela @NicolasMaduro pic.twitter.com/QHP90u3GBH\n— Pedro Infante (@pinfantepsuv) 12 de julio de 2016\n\n\n\n#COVSelfieOlimpico La iniciativa camino a @rio2016_es agrupa cada estrato de la sociedad criolla @rubenoszki pic.twitter.com/f9gUw90VEx\n— PUNTO OLIMPICO (@PuntoOlimpico) 13 de julio de 2016\n\nPRENSA TVES &#8211; Nailin Zambrano	Thu, 14 Jul 2016 22:26:19 +0000	9.jpg	1	Noticias
4	Vamos Pa’ Río: Descubra el tema oficial de los Juegos Olímpicos	http://www.tves.gob.ve/olimpiadas2016/?p=248	Con mucha alegría y música los Juegos Olímpicos de Río 2016 posee su canción oficial y en TVES se la presentamos.\nSe dice que el deporte y la música son los idiomas universales capaces de traspasar cualquier barrera, nación o ideología. Este año no será la excepción, cuando la música de vida a los Juegos Olímpicos Río de Janeiro 2016. Más de 10.500 atletas y un total de 206 delegaciones darán un espectáculo de primer nivel en el país ‘verdeamarelo’.\nEl dúo brasileño DJs Tropkillaz son los encargados de interpretar la canción oficial de estos juegos: “Alma y corazón” con letra de MC Léo da Baixada, Víctor Reis y Rodrigo Marques.\nEl tema musical es entonado por un dúo integrado por el rapero Projota y el artista pop Thiaguinho, que además fueron grabados en el Estadio Olímpico, en algunas locaciones en Río, incluido el Estadio Acuático Olímpico, la playa de Leblon y la favela Vidigal.\nA continuación la presentación del video oficial:\n\nFuente: Alan Muro / Prensa Tves	Tue, 19 Jul 2016 13:58:55 +0000	4.jpg	1	Noticias
10	Alejandra Benítez: Un ejemplo de constancia y compromiso	http://www.tves.gob.ve/olimpiadas2016/?p=224	La esgrimista emplea todo su esfuerzo para traerle una alegría más al pueblo deportivo venezolano\nLa Televisora Venezolana Social (TVES) se alista para el evento deportivo más importante del mundo, los Juegos Olímpicos Río 2016 y el seguimiento de cada atleta es nuestra  bandera a pocos días del inicio de esta magna cita. La delegación venezolana contará con 86 atletas, cifra superada con respecto a los 69 clasificados en Londres 2012.\nLa disciplina de esgrima ha sido estandarte en los últimos años para el país, por lo tanto Venezuela tendrá grandes expectativas en la participación de dicha escuadra.\nLa criolla Alejandra Benítez con un palmarés de preseas bronceadas y plateadas en los torneos Panamericanos de Esgrima y Juegos Panamericanos respectivamente, se prepara de manera vertiginosa para Río 2016. A través de su cuenta oficial en la red social Twitter, muestra todo su camino a los Juegos Olímpicos en el país carioca, sumando distintas publicaciones de los organismos a disposición de los deportistas.\n\nBuen inicio de semana: preparación física, trabajo técnico- táctico, electro estimulación y ahora recuperación (piscina, sauna y crío) \n— Alejandra Benitez R (@BenitezVEN) 5 de julio de 2016\n\n\nNuestra @BenitezVEN logró su clasificación a los JJOO en la Copa Mundial Grand Prix SK Telecom Seul #VamosPaRio pic.twitter.com/wOASuh3MCU\n— IND (@IND_Vzla) 13 de julio de 2016\n\n\n\nContinuamos trabajando como un gran equipo a los JJOO pic.twitter.com/5M4DAnHhlA\n— Alejandra Benitez R (@BenitezVEN) 14 de julio de 2016\n\n\nLos invito a visitar mi página WEB https://t.co/FzWmBkwamv Y con tan solo un click abrirás una ventana de mi vida pic.twitter.com/C8F1g8Dw9h\n— Alejandra Benitez R (@BenitezVEN) 2 de abril de 2016\nALAN MURO &#8211; GERENCIA WEB Y REDES\n\n	Thu, 14 Jul 2016 22:16:05 +0000	10.jpg	1	Noticias
5	Curiosidades históricas sobre la delegación venezolana en Río 2016	http://www.tves.gob.ve/olimpiadas2016/?p=244	Venezuela este año tendrá la oportunidad de participar en sus Juegos Olímpicos número 18 y Río de Janeiro será el escenario donde los atletas criollos saltarán en la búsqueda de una nueva alegría para el país, la obtención de preseas.\nUn total de 86 atletas, cifra superada en la pasada cita olímpica en Londres 2012 (69 venezolanos) serán quienes digan presente en el nación amazónica. La esperanza de medalla está intacta y nuestro abanderado Rubén Limardo desea revalidar su triunfo obtenido en Londres.\nEn la Televisora Venezolana Social (TVES) único canal en señal abierta OFICIAL de los Juegos Olímpicos Río de Janeiro 2016, te ofrece unos datos de curiosidad e interés para que te llenes de alegría y compartas información del evento deportivo más grande del mundo.\n¿Sabías que este año vuelve el golf a la cita olímpica y Venezuela tendrá participación?\nSí, más de un siglo tenía la disciplina del golf sin hacer presencia en unos Juegos Olímpicos, y este 2016 volverán por la puerta grande. Tras su desaparición en 1904, una reunión realizada en Copenhague (Dinamarca) en el año 2009, el Comité Olímpico Internacional decidió tomar como positivo el regreso del deporte con 63 votos favorables y un total de 27 en contra con dos abstenciones.\nVenezuela tendrá la dicha de participar en esta hermosa disciplina con un excelente atleta, él es Jhonattan Vegas. Número 46 en el ranking mundial y 38 en el principal circuito de golf profesional masculino en Estados Unidos, el PGA Tour (Ver más)\n\nPor segunda ocasión en 68 años un esgrimista llevará el pabellón nacional\nLa primera ocasión fue en México 1968 cuando Silvio Fernández (Padre) llevó el estandarte criollo. En ese año 23 atletas tuvieron participación en cinco disciplinas.\nComo dato curioso, Silvio Fernández (Hijo) forma parte de representación venezolana que en este 2016 es dirigida por el espadista Rubén Limardo.\nLimardo tendrá como responsabilidad llevar el tricolor nacional, además de revalidar esa medalla dorada histórica lograda en Londres 2012.\n\n\n\nLa segunda mayor cantidad de atletas en la historia\nLuego de la cifra record lograda en el año de 2008 en los Juegos de Pekín con 109 deportistas, Venezuela tendrá la segunda mayor cantidad de representantes en toda su historia como participante. En esta ocasión son 86 quienes estarán viendo acción en 20 disciplinas.\n\n\n\nSegunda vez en la historia que una selección de baloncesto disputa una medalla\nLuego del campeonato sudamericano obtenido el pasado 2 de julio en el Poliedro de Caracas, la Vinotinto de las alturas se prepara con todo para luchar con las 11 mejores selecciones del mundo, buscando seguir haciendo historia en el baloncesto venezolano.\nPerteneciente al Grupo A, Venezuela dirá presente en el baloncesto olímpico por segunda vez en la historia (la primera, en Barcelona 92 con los catalogados ‘Héroes de Portland’). Los criollos no la tendrán fácil, no obstante, a menos de 20 días del certamen, mantienen una intensa gira por Europa y Norteamérica en búsqueda de un excelente nivel de juego (Ver más)\n\n\n\nSon 12 preseas las obtenidas por Venezuela desde 1948\nUn total de 12 medallas ha conquistado la delegación venezolana en toda la historia en Juegos Olímpicos. Desde Helsinki 1952 con un bronce de Asnoldo Devonish en Salto triple hasta Rubén Limardo con un oro en Esgrima obtenido en Londres 2012.\n\n\n\nAquí un despliegue de las históricas premiaciones con sus atletas y disciplinas:\n\n\n\n\n\n\n\n\nDisciplina\n\n\nOro\n\n\nPlata\n\n\nBronce\n\n\nT\n\n\nDetalle\n\n\n\n Boxeo\n1\n2\n2\n5\n Oro de Francisco &#8220;Morochito&#8221; Rodríguez, México 1968, -48 kilogramos\nPlata de Pedro Gamarro, Montreal 1976, 63.5 &#8211; 67 kilogramos\nPlata de Bernardo Piñango, Moscú 1980, 51-54 kilogramos\nBronce de Marcelino Bolívar, Los Angeles 1984, -48 kilogramos\nBronce de Omar Catarí, Los Angeles 1984, 54-57 kilogramos\n\n\n Esgrima\n1\n0\n0\n1\n Oro de Rubén Limardo, Londres 2012, Espada individual\n\n\n Taekwondo\n0\n0\n2\n2\n Bronce de Adriana Carmona, Atenas 2004, +67 kilogramos\nBronce de Dalia Contreras, Pekín 2008, -49 kilogramos\n\n\n Atletismo\n0\n0\n1\n1\n Bronce de Asnoldo Devonish, Helsinki 1952, Salto triple\n\n\n Halterofilia\n0\n0\n1\n1\n Bronce de Israel Rubio, Atenas 2004, 62 kilogramos\n\n\n Natación\n0\n0\n1\n1\n Bronce de Rafael Vidal, Los Angeles 1984, 200 m mariposa\n\n\n Tiro deportivo\n0\n0\n1\n1\n Bronce de Enrico Forcella, Roma 1960, Rifle tendido 50 m\n\n\n\nTOTAL\n\n2\n2\n8\n12\n\n Cuadro: Enciclopedia Libre\n\n\n\n\n\nFuente: Alan Muro / Prensa Tves	Tue, 19 Jul 2016 13:48:57 +0000	5.jpg	1	Noticias
6	Atletas criollos batallarán en Río	http://www.tves.gob.ve/olimpiadas2016/?p=241	Venezuela estará representada en los Juegos Olímpicos de Río, que se celebrarán entre el 05 y el 21 de agosto del corriente, por 86 deportistas en 19 disciplinas, la segunda delegación venezolana más numerosa después de la compuesta por 110 competidores en la edición de Beijing 2008.\nEl abanderado por el pueblo venezolano será el campeón olímpico de esgrima Rubén Limardo, quien gozó con el respaldo de la población entera.\nLimardo, medallista de oro en Londres 2012, participará a sus terceros juegos con el objetivo de revalidar su presea dorada para emular el cubano Ramón Fonst, quien lo logró en las ediciones de París 1900 y San Luis 1904.\nLa cifra de deportistas clasificados a Río de Janeiro superó las proyecciones hechas por las autoridades deportivas venezolanas, que esperaban desplazar a 70 representantes, según el mismo Mervin Maldonado, ministro del Poder Popular para la Juventud y el Deporte.\n“Estamos de fiesta por haber logrado superar el número de atletas clasificados a Río. Esto habla de la inversión del Estado venezolano para con sus deportistas. Esto se logró gracias al trabajo mancomunado y hermanado de todos”, dijo Maldonado.\nLA DELEGACIÓN\nVenezuela llevará a Río a un total de 61 hombres y 25 mujeres y según Eduardo Álvarez, presidente del Comité Olímpico Venezolano (COV) es una de las más completas de la historia.\n“Contamos con una delegación bastante completa que es integrada por juventud y experiencia. Estoy seguro de que nuestros guerreros darán su mejor esfuerzo por brillar en Río”, agregó Álvarez.\nLa disciplina con mayor número de clasificados es el atletismo 15, seguida del baloncesto masculino (12), la lucha (9), el ciclismo (9) y el boxeo (8).\nSe estima que la delegación podría incrementarse con la dupla de volibol de playa masculino, que esperan una respuesta de la Federación Internacional de la disciplina, sobre el equipo de Egipto, que no cumplió con las 12 paradas para poder clasificar y sobre un caso de dopaje en la misma disciplina.\n\nLOS ATLETAS\nStefany Hernández, que asistirá a su segundos Juegos tras finalizar en el noveno puesto en Londres 2012, se convirtió en campeona del mundo de BMX en 2015 en la competencia realizada en Zolder, Bélgica, y actualmente ocupa el octavo lugar de la clasificación mundial de la Unión Ciclística Internacional (UCI) con 1.024 puntos.\nYulimar Rojas debutará en esta cita olímpica en el salto triple, tras haber clasificado en los Juegos Panamericanos de Toronto 2015, donde logró una marca de 14,20 metros, que superó en los Campeonatos Mundiales de Atletismo bajo techo en Portland, Estados Unidos, donde ganó el oro con un salto de 14,41 metros.\nRojas, de 20 años, es la revelación de la delegación venezolana, pues tras esos logros consiguió la medalla de plata en su debut en la Liga de Diamante, en la parada de Doha, Catar, con un salto de 14,79 metros, y el primer lugar de la Reunión de Madrid, España, con un salto de 15,02 metros.\nLa selección de baloncesto masculina venezolana conquistó la medalla de oro y el pasaporte a Río en el Preolímpico de México en 2015, y revalidó el título del Campeonato Sudamericano en Caracas.\nLa delegación criolla es una de las que contará con un golfista, tras la clasificación de Jhonattan Vegas, en el regreso de la disciplina al calendario olímpico tras 112 años de ausencia.\nAdemás tendrá a tres deportistas que acudirán a sus cuartos Juegos Olímpicos: los esgrimistas Silvio Fernández, Alejandra Benítez, y el nadador Albert Subirats, quienes participaron en las ediciones de Atenas 2004, Pekín 2008 y Londres 2012.\nVía: Correo del Orinoco	Mon, 18 Jul 2016 17:23:37 +0000	6.jpg	1	Noticias
7	Yulimar Rojas: ¡Esperanza olímpica!	http://www.tves.gob.ve/olimpiadas2016/?p=238	La atleta venezolana Yulimar Rojas, vigente campeona mundial de salto triple bajo techo y una clara esperanza de medalla olímpica en los Juegos de Río, que se efectuarán del 5 al 21 de agosto, dio otra señal de ir en la dirección correcta, al concluir como subcampeona en el Meeting Internacional Hércules de Mónaco, parada de la Liga de Diamante de Atletismo.\nRojas completó un intento de 14.64 metros en el quinto de sus seis chances, con el que se aseguró un lugar como escolta de la campeona mundial colombiana Caterine Ibargüen, la mejor atleta del planeta en esta modalidad y quien se hizo con el primer puesto mediante un salto de 14.96 metros.\n“He trabajando muy duro para poder ver estos resultados. Estoy feliz por todo lo que he logrado en tan poco tiempo. Sé que estos no serán mis juegos, pero voy con todo a buscar una medalla para mi país”, declaró la criolla.\nLa participación de Yulimar Rojas en la Liga de Diamantes, torneo que congrega a las y los mejores del planeta, es parte de la preparación que tiene prevista la Federación Venezolana de Atletismo, el Ministerio del Poder Popular para la Juventud y el Deporte y el Instituto Nacional del Deporte (IND).\nAl respecto Pedro Infante, presidente del IND indicó: “Hemos planeado un excelente plan de preparación para Yulimar Rojas, quien obviamente es una de nuestras esperanzas olímpicas. Estamos buscando la manera de garantizarle la mayor tranquilidad y comodidad para que cumpla con el objetivo de la patria”.\nSe estima que Yulimar Rojas, esté arribando a Brasil en los próximos días, para iniciar la fase de adaptación a las condiciones climáticas de la zona, para intentar consagrarse en las competencias más importantes del planeta.\nLa jamaiquina Kimberly Williams concluyó en la tercera posición con un intento efectivo de 14.47 metros, en tanto que la vigente campeona olímpica, Olga Rypakova de Kazajistán, tuvo que conformarse con un sexto lugar (13.97 metros), superada por la portuguesa Patricia Mamona (14.24) y la ucraniana Olga Saladukha (14.03).\nLa jamaiquina Williams tenía la aspiración de colarse entre Ibargüen y Rojas y salió decepcionada.\nEs la segunda vez que Rojas se mete en el podio en una de las paradas de la Liga de Diamante, toda vez que en el mes de mayo logró un segundo lugar en Doha, Catar, gracias a un salto de 14.92 metros. Su título del orbe bajo techo en categoría adulta había llegado dos meses antes en el campeonato de Estados Unidos, mediante un intento de 14.41 metros.\nEn ese momento se convirtió en la tercera venezolana con una medalla en campeonatos mundiales de atletismo tras Keisa Monterola (plata Marruecos 2005) y Robeilys Peinado (oro sub18 Ucrania 2016), ambas en salto con pértiga.\nAntes de esta justa, Rojas no intervino en Birmingham, Inglaterra, en cita en la que Ibargüen fue derrotada por Rypakova para perder una seguidilla de 34 triunfos. Llegaba a esta parada en la cuarta posición de la Liga de Diamante con nueve puntos como escolta de Ibargüen (36), Rypakova (20) y la griega Paraskevi Papachristou (10), según la tabla provista por la Federación Internacional de Atletismo (IAAF).\nVía: Correo del Orinoco	Mon, 18 Jul 2016 17:22:39 +0000	7.jpg	1	Noticias
1	TVES organizó Encuentro Olímpico en víspera Río 2016	http://www.tves.gob.ve/olimpiadas2016/?p=262	TVes ofrecerá una cobertura completa y exclusiva con más de 12 horas de transmisión EN DIRECTO de manera diaria.\nLa Televisora Venezolana Social (TVES) hizo la presentación formal este miércoles como Canal Oficial de los Juegos Olímpicos Río 2016, que transmitirá la cita deportiva desde el 05 hasta el 21 de agosto.\nNuestro estudio grande fue escenario de esta ceremonia, en la que participaron dirigentes deportivos, representantes de atletas, prensa nacional, además de las distintas embajadas que estrechan lazos con Venezuela.\nEl Director Ejecutivo de la planta televisiva, Rodolfo Vilchez, inauguró el evento y dio la bienvenida a los diferentes medios de comunicación. Posteriormente mostró el video promoción que ubica a TVES como el único canal en señal abierta, enlazando la Televisión Digital Abierta (TDA) para todos los usuarios que deseen la transmisión de Río2016 en alta definición.\nPor su parte, el presidente del Instituto Nacional de Deportes (IND), Pedro Infante, compartió impresiones con todos los presentes, aseverando el apoyo constante de los entes gubernamentales para el entrenamiento de cada uno de nuestros atletas. &#8220;Venezuela se está preparando para dar el todo por el todo en esta cita olímpica&#8221;, dijo Infante.\n“Vamos convencidos de que será la mejor actuación de Venezuela con resultados muy positivos (…) 30 millones de almas apoyarán a nuestros 86 guerreros y guerreras que darán todo por la Patria”, culminó Pedro Infante.\nLos atletas siguen preparándose de manera ardua para el evento más importante del deporte mundial, y parte de su representado hizo acto de presencia en la locación.\nJuan José Sayago, jefe de presa de la atleta en BMX, Stefany Hernández, y cuerpo de prensa de los esgrimistas criollos,  aseguró que continúa la exigencia en los entrenamientos  rumbo a Río 2016.\n“Quisimos que muchos de nuestros atletas estuvieran presente en el país para esta presentación, no obstante, la preparación y los entrenamientos de los deportistas, aunado a las diferencias horarias, compromete el contacto directo con cada uno de ellos”, expresó.\nComo canal deportivo y de sano entretenimiento para la familia venezolana, el Desayuno Olímpico presentó parte de su talento que dirá presente en cada una de las transmisiones EN VIVO, sumando los enviados especiales desde el lugar de los acontecimientos.\nTVES ofrecerá una cobertura completa y exclusiva con más de 12 horas de transmisión EN DIRECTO de manera diaria.\nMás de 10 mil 500 atletas, 206 comités olímpicos nacionales y un total de 306 eventos en 28 disciplinas deportivas son las que a partir del 5 hasta el 21 de agosto darán vida a la fiesta en el gigante asiático.  \nCon el lema ‘Un Mundo Nuevo’ el deporte será la unión de todo el globo terráqueo en este suceso transcendental, en el que nuestra Venezuela Potencia brillará.\nFuente: Alan Muro / Prensa Tves	Fri, 22 Jul 2016 19:31:24 +0000	1.jpg	1	Noticias
2	Robeilys Peinado conquistó la plata en Polonia	http://www.tves.gob.ve/olimpiadas2016/?p=259	La caraqueña saltó 4 metros con 40 centímetros > Ahora se prepara para viajar a Río de Janeiro.\nLa atleta venezolana Robeilys Peinado consiguió la medalla de plata, en la especialidad de salto con pértiga, tras alcanzar 4 metros, 40 centímetros en el Campeonato Mundial de atletismo sub 20, que se disputa en el Estadio Sawisza de la ciudad polaca de Bydgoszcz.\nDe esta manera hace historia en el atletismo venezolano, al convertirse en la primera criolla que gana una presea en un mundial de la categoría sub 20.\nLa joven caraqueña compartió el podio con la representante de Suiza, Angélica Moser, quien saltó 4.55, y la finlandesa Wilma Murto que dejó un registro de 4.40.\nPeinado continúa su programa de entrenamiento y preparación, con miras a los próximos Juegos Olímpicos Río de Janeiro, Brasil, donde la criolla nuevamente enfrentará a las mejores garrochistas del mundo.\nLa caraqueña, campeona mundial menor, sub 18 de Ucrania 2013, figura en la primera casilla de la clasificación júnior de 2016, con registro de 4 metros, con 56 centímetros.\nRobeilys Peinado quedó de primera y pasó a la final de salto con pértiga durante la primera ronda, realizada el día miércoles.\nEn la ronda eliminatoria del evento mundialista, solo la venezolana y la suiza, Angélica Moser, (ganadora de la medalla de oro en los Juegos Olímpicos Juveniles de Nanjing 2014) lograron la marca requerida de 4.20 metros.\nPara las Olimpiadas Río 2016, sus rivales por la medalla de oro serán Angélica Moser, la sueca Lisa Gunnarsson y la finlandesa Wilma Murto, acreedora del récord de 4.71 metros logrados en eventos bajo techo y 4.52 al aire libre.\nRobeylis Peinado ha tenido una extraordinaria y rápida carrera en la especialidad con garrocha y tiene dos fechas que han marcado su vida. La primera fue el 24 de mayo de 2010, cuando saltó 4,35 en el Campeonato Nacional Menor de Barquisimeto y borró en un solo brinco todos los récords nacionales e internacionales que poseía Keisa Monterola y el 13 de julio de 2013, cuando dejó de ser una promesa del atletismo, para convertirse en la primera campeona mundial de su deporte, en la categoría menor sub 18.\nRobeilys está consciente de la importancia de sus éxitos y considera que muchos atletas tengan iguales triunfos, pero su meta por ahora es conquistar una medalla en Juegos Olímpicos.\nFuente: Ciudad Caracas	Fri, 22 Jul 2016 19:28:55 +0000	2.jpg	1	Noticias
\.


--
-- Name: noticias_id_seq; Type: SEQUENCE SET; Schema: noticias; Owner: administrador
--

SELECT pg_catalog.setval('noticias_id_seq', 10, true);


--
-- Data for Name: rss_not; Type: TABLE DATA; Schema: noticias; Owner: administrador
--

COPY rss_not (id_not, url, titulo, enlace) FROM stdin;
1	http://www.tves.gob.ve/olimpiadas2016/?cat=3&feed=rss2	noticias	http://www.tves.gob.ve/olimpiadas2016/
\.


--
-- Name: rss_noticias_id_not_seq; Type: SEQUENCE SET; Schema: noticias; Owner: administrador
--

SELECT pg_catalog.setval('rss_noticias_id_not_seq', 1, true);


SET search_path = programacion, pg_catalog;

--
-- Data for Name: programacion; Type: TABLE DATA; Schema: programacion; Owner: administrador
--

COPY programacion (id, programa, hora, src_id, categoria, fecha, sinopsis, dia) FROM stdin;
1	Ciclismo	08:30 am	1	Programación	22-07-16	Los Venezolanos buscarán obtener el mayor número de medallas para esta competencia. Tenemos la amplia posibilidad de llegar a la cantidad de 18 atletas clasificados a Río, eso nos colocaría como la Federación que más atletas aporta a la delegación criolla. Nuestros deportistas tienen oportunidad de lograr sus marcas hasta el 12 de julio que cierra el calendario de competencias internacionales.	Viernes
2	Esgrima	10:30 am	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
3	Pesas	01:00 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
4	Ciclismo	09:00 am	1	Programación	22-07-16	Los Venezolanos buscarán obtener el mayor número de medallas para esta competencia. Tenemos la amplia posibilidad de llegar a la cantidad de 18 atletas clasificados a Río, eso nos colocaría como la Federación que más atletas aporta a la delegación criolla. Nuestros deportistas tienen oportunidad de lograr sus marcas hasta el 12 de julio que cierra el calendario de competencias internacionales.	Viernes
5	Maratón	11:00 am	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
6	Natación	01:00 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
7	Esgrima	01:30 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
8	Atletismo	02:00 pm	1	Programación	22-07-16	Los Venezolanos buscarán obtener el mayor número de medallas para esta competencia. Tenemos la amplia posibilidad de llegar a la cantidad de 18 atletas clasificados a Río, eso nos colocaría como la Federación que más atletas aporta a la delegación criolla. Nuestros deportistas tienen oportunidad de lograr sus marcas hasta el 12 de julio que cierra el calendario de competencias internacionales.	Viernes
9	Natación	03:00 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
10	Natación	04:00 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
11	Atletismo	05:00 pm	1	Programación	22-07-16	Los Venezolanos buscarán obtener el mayor número de medallas para esta competencia. Tenemos la amplia posibilidad de llegar a la cantidad de 18 atletas clasificados a Río, eso nos colocaría como la Federación que más atletas aporta a la delegación criolla. Nuestros deportistas tienen oportunidad de lograr sus marcas hasta el 12 de julio que cierra el calendario de competencias internacionales.	Viernes
12	Natación	05:30 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
13	Natación	06:00 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
14	Natación	06:30 pm	1	Programación	22-07-16	Albert Subirats lo logró de nuevo. Con un crono de 51.90, el tritón criollo se coronó en la final de los 100 mariposa del Campeonato Suramericano de Natación de Paraguay, y consiguió la marca mínima para acceder a los JJOO de Río, los cuartos de su carrera.	Viernes
\.


--
-- Name: programacion_id_seq; Type: SEQUENCE SET; Schema: programacion; Owner: administrador
--

SELECT pg_catalog.setval('programacion_id_seq', 14, true);


--
-- Data for Name: rss_prog; Type: TABLE DATA; Schema: programacion; Owner: administrador
--

COPY rss_prog (id_prog, url, titulo, enlace) FROM stdin;
1	http://www.tves.gob.ve/olimpiadas2016/?cat=5&feed=rss2	Programacion	http://www.tves.gob.ve/olimpiadas2016/
\.


--
-- Name: rss_prog_id_prog_seq; Type: SEQUENCE SET; Schema: programacion; Owner: administrador
--

SELECT pg_catalog.setval('rss_prog_id_prog_seq', 1, true);


SET search_path = calendario, pg_catalog;

--
-- Name: calendario_pkey; Type: CONSTRAINT; Schema: calendario; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY calendario
    ADD CONSTRAINT calendario_pkey PRIMARY KEY (id);


--
-- Name: rss_cal_pkey; Type: CONSTRAINT; Schema: calendario; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY rss_cal
    ADD CONSTRAINT rss_cal_pkey PRIMARY KEY (id_cal);


SET search_path = medallero, pg_catalog;

--
-- Name: medallero_pkey; Type: CONSTRAINT; Schema: medallero; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY medallero
    ADD CONSTRAINT medallero_pkey PRIMARY KEY (id);


--
-- Name: rss_med_pkey; Type: CONSTRAINT; Schema: medallero; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY rss_med
    ADD CONSTRAINT rss_med_pkey PRIMARY KEY (id_med);


SET search_path = noticias, pg_catalog;

--
-- Name: noticias_pkey; Type: CONSTRAINT; Schema: noticias; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY noticias
    ADD CONSTRAINT noticias_pkey PRIMARY KEY (id);


--
-- Name: rss_noticias_pkey; Type: CONSTRAINT; Schema: noticias; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY rss_not
    ADD CONSTRAINT rss_noticias_pkey PRIMARY KEY (id_not);


SET search_path = programacion, pg_catalog;

--
-- Name: programacion_pkey; Type: CONSTRAINT; Schema: programacion; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY programacion
    ADD CONSTRAINT programacion_pkey PRIMARY KEY (id);


--
-- Name: rss_prog_pkey; Type: CONSTRAINT; Schema: programacion; Owner: administrador; Tablespace: 
--

ALTER TABLE ONLY rss_prog
    ADD CONSTRAINT rss_prog_pkey PRIMARY KEY (id_prog);


SET search_path = calendario, pg_catalog;

--
-- Name: calendario_src_id_fkey; Type: FK CONSTRAINT; Schema: calendario; Owner: administrador
--

ALTER TABLE ONLY calendario
    ADD CONSTRAINT calendario_src_id_fkey FOREIGN KEY (src_id) REFERENCES rss_cal(id_cal) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = medallero, pg_catalog;

--
-- Name: medallero_src_id_fkey; Type: FK CONSTRAINT; Schema: medallero; Owner: administrador
--

ALTER TABLE ONLY medallero
    ADD CONSTRAINT medallero_src_id_fkey FOREIGN KEY (src_id) REFERENCES rss_med(id_med) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = noticias, pg_catalog;

--
-- Name: noticias_src_id_fkey; Type: FK CONSTRAINT; Schema: noticias; Owner: administrador
--

ALTER TABLE ONLY noticias
    ADD CONSTRAINT noticias_src_id_fkey FOREIGN KEY (src_id) REFERENCES rss_not(id_not) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = programacion, pg_catalog;

--
-- Name: programacion_src_id_fkey; Type: FK CONSTRAINT; Schema: programacion; Owner: administrador
--

ALTER TABLE ONLY programacion
    ADD CONSTRAINT programacion_src_id_fkey FOREIGN KEY (src_id) REFERENCES rss_prog(id_prog) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

