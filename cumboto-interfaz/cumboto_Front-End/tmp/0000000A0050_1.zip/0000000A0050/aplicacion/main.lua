--[[
__autor__   = "Yngris Ibargüen"
__email__   = "zyngris@gmail.com"
__date__    = "2015-05-10"
__version__ = "beta-0.2"
__license__ = "GPLv2"
]]
--modulos 
require 'modules.encode.json'
require 'modules.data.data_red'
require 'modules.data.data_green'
require 'modules.data.data_blue'
require 'modules.data.data_yellow'


--Variables Globales
local json = require("json")
local indice_final_pagina=0
local indice_palabras_final=0
local pagina={}
local final_pagina = "NO"
local indice_pagina=0
local palabras_pagina=0
local indice_palabras=1
local indice_titulo=1
local indice_elemento= 1
local boton_inicial="r"
local contador_elementos = 0
local indice_rss = 0
local indice_elementos = 1
local posicion_fila_texto = 60
local posicion_columna = 135
local color_categoria = "red"
local posicion_fila_imagen = 425
local posicion_columna_imagen = 320
local col=0
local row=0
local texto=""
local separacion_filas = 1
local separacion_filas_title = 1.3
local inicio_columna = 0
local setup_pantallas={ 
  red = {
    title = "theme/title_red.png",
    tab = "theme/tab_red.png"
  },
  green = {
    title = "theme/title_green.png",
    tab = "theme/tab_green.png"
  },
  yellow = {
    title = "theme/title_yellow.png",
    tab = "theme/tab_yellow.png"
  },
  blue = {
    title = "theme/title_blue.png",
    tab = "theme/tab_blue.png"
  }
}

--********************************* Funciones de la Aplicación ************************************* 

-- Función para limpiar la pantalla.

function Limpiar_Pantalla()
  canvas:attrColor(0,0,0,0)
  canvas:clear(20, 190,450,400) --limpia los elementos
  canvas:clear(369, 279,332 ,220) -- limpia la imagen
  --canvas:clear()
end

-- Función para leer y decodificar las secuencias de escape del texto con json.

function Leer_elementos(color)
            
  if color == "red" then
    local data = require("data_red")
    elementos = json.decode(data.FEEDS) 
    color_categoria="red"   
  end

  if color == "green" then
    local data = require("data_green")
    elementos = json.decode(data.FEEDS) 
    color_categoria="green"   
  end

  if color == "yellow" then 
    local data = require("data_yellow")
    elementos = json.decode(data.FEEDS) 
    color_categoria="yellow"
  end

  if color == "blue" then 
    local data = require("data_blue")
    elementos = json.decode(data.FEEDS) 
    color_categoria="blue" 
  end    
    
end

-- Función para pintar el fondo de la aplicación de acuerdo al color seleccionado.

function Pintar_Fondo_elemento(color)
  
  canvas:attrColor(0,0,0,0)
  canvas:clear (0, 0, 720 , 576)
  --canvas:compose(0,0, canvas:new("theme/bg.png"))
  canvas:flush()
    
end

--Función para la ejecución de los eventos en la aplicación de acuerdo a la teclas pulsadas.

function Eventos_Aplicacion(boton)

  if boton.class=="ncl" and boton.type=="attribution" then
  
    if boton.value == "up" then
      Pintar_Elementos_Aplicacion("u")
    end 

    if boton.value == "down" then
      Pintar_Elementos_Aplicacion("d")
    end 
    
    if boton.value == "left" then
      Pintar_Elementos_Aplicacion("l")
    end 

    if boton.value == "right" then
      Pintar_Elementos_Aplicacion("r")
    end 

    if boton.value == "red" or boton.value == "green" or boton.value == "yellow" or boton.value == "blue" then
      Pintar_Fondo_elemento(boton.value)
      Leer_elementos(boton.value) 
      contador_elementos = 0
      indice_rss = 1
      indice_elementos = 1
      indice_titulo=1
      indice_elemento=1
      indice_palabras=1
      indice_pagina=0
      palabras_pagina=0
      indice_final_pagina=0   
      final_pagina = "NO" 
      Pintar_Elementos_Aplicacion(boton.value)
	  	
    end 

  end 

end


--Función para pintar los elementos en la interfaz de la aplicación.


function Pintar_Elementos_Aplicacion(boton)
    
	  if elementos.category[color_categoria] then
		contador_elementos = #elementos.category[color_categoria].rss
	  else
		Limpiar_Pantalla()
		canvas:clear (0, 0, 720 , 576)
		canvas:attrColor(0,0,0,256)
		canvas:attrFont("Tiresias", 14, "bold")
		canvas:drawText(posicion_fila_texto, posicion_columna + 45, "La categoría seleccionada no contiene elementos...")
		image = canvas:new("media/0.jpg")
		canvas:compose(posicion_fila_imagen, posicion_columna_imagen, imagen_elemento)
		canvas:flush()
		return
	  end
	  
	  if contador_elementos > 0 then
		if indice_rss == 0 then 
		  indice_rss = 1
		end
	  else
		  return
	  end
	  
	  if boton == "r" then

		final_pagina = "NO"
		palabras_pagina=0
		indice_pagina=0
		indice_palabras=1
		indice_titulo=1
		indice_elemento= 1
		indice_final_pagina=0
		if color_categoria == "blue" then
			separacion_filas=1.5
			inicio_columna=5
    	end
		
		if (indice_elementos + 1) <= #elementos.category[color_categoria].rss[indice_rss].channel.item then
		  indice_elementos = indice_elementos + 1
		else 
		  if (indice_rss + 1) <= contador_elementos then
		    indice_rss = indice_rss + 1
		    indice_elementos = 1
		  end
		end

	  end  
	 
	  if boton == "l" then

		final_pagina = "NO"
		palabras_pagina=0
		indice_pagina=0
		indice_palabras=1   
		indice_titulo=1
		indice_elemento=1
		indice_final_pagina=0 
		
    
	  
		if (indice_elementos - 1) <= #elementos.category[color_categoria].rss[indice_rss].channel.item and (indice_elementos - 1) > 0 then
		  indice_elementos = indice_elementos - 1
		else
		  if (indice_rss - 1) <= contador_elementos and (indice_rss - 1) > 0 then
		    indice_rss = indice_rss - 1
		    indice_elementos = #elementos.category[color_categoria].rss[indice_rss].channel.item
		  end
		end

	  end
	   
	  if boton == "u" then

		indice_elemento=1    
		indice_titulo=1

		if indice_pagina - 1 > 0 then
		  indice_palabras=pagina[indice_pagina-1] + 1
		end 
		      
		if indice_pagina > 0 then
		  indice_pagina=indice_pagina-1
		end    

		if  indice_pagina == 0 then
		  indice_palabras=1
		  palabras_pagina=0
		end

	  end 
		
	  if boton == "d" then
		  
		indice_elemento=1    
		indice_titulo=1
		  
		if indice_pagina  < indice_final_pagina then
		  indice_pagina=indice_pagina + 1 
		  indice_palabras=pagina[indice_pagina] + 1
		end     
		           
		if palabras_pagina < texto_descripcion and final_pagina == "NO" then
		  indice_pagina=indice_pagina + 1
		  pagina[indice_pagina]=palabras_pagina
		  indice_palabras=pagina[indice_pagina] + 1
		  indice_palabras_final=palabras_pagina + 1
		end
		  
		if indice_pagina == indice_final_pagina then
		  indice_palabras=indice_palabras_final
		end
	   
     end

--********************************* Dibujar el titulo **************************

  Limpiar_Pantalla()
  canvas:attrColor(0,0,0,256)
  canvas:clear (0, 0,0,400)
  canvas:attrFont("Tiresias", 16, "bold")

  -- Pinta el Titulo de la pantalla
  canvas:compose(355,160, canvas:new(setup_pantallas[color_categoria].title))

  -- Pinta la Pestaña con la información de la pantalla. Solo para los colores: red, green, yellow
  if color_categoria~="blue" then
    canvas:compose(20,270, canvas:new(setup_pantallas[color_categoria].tab))
  end

  if color_categoria=="blue" then

    for i = 1, #elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].titulo, 1 do
      
      posicion_columna_texto = posicion_columna + 80
      texto=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].titulo[i].words
      col=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].titulo[i].col
      row=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].titulo[i].row        
      
      if row == 0 then
		      indice_titulo=indice_titulo+separacion_filas_title
		  end

		  canvas:drawText(posicion_fila_texto+row+5, posicion_columna_texto+col*indice_titulo, texto)
			
		end

    
  else

    posicion_columna_texto = 0

  end


--********************************* Dibujar la Fecha ********************************      
   
  --[[
  posicion_columna_texto = posicion_columna_texto + 105
  canvas:attrFont("Tiresias", 12)
  canvas:drawText(posicion_fila_texto+5, posicion_columna_texto, elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].fecha)
  ]]--

--**************************** Dibujar los elementos  ********************************  
  
 

  if color_categoria == "red" then

    -- Configuración de las coordenadas de los elementos de acuerdo al color seleccionado

	posicion_columna_texto = 265
	separacion_filas=1.6
	inicio_columna=190

    -- Pinta el Fondo de la Tabla de Contenidos de Programación

    	canvas:compose(235,260, canvas:new("theme/bg_tabla_programacion.png"))

    -- Pinta las Flechas Arria y Abajo para la Navegación

        canvas:compose(555,300, canvas:new("theme/arrow_up.png"))
        canvas:compose(555,380, canvas:new("theme/arrow_down.png"))

    -- Color de la fuente en la tabla de contenidos

        canvas:attrColor(0,0,0,256)

   end
	
   if color_categoria == "green" then

    -- Configuración de las coordenadas de los elementos de acuerdo al color seleccionado

	posicion_columna_texto = 265
	separacion_filas=1.6
	inicio_columna=190

    -- Pinta el Fondo de la Tabla de Contenidos de Medallero

    	canvas:compose(235,260, canvas:new("theme/bg_tabla_medallero.png"))

    -- Pinta las Flechas Arria y Abajo para la Navegación

   	canvas:compose(665,300, canvas:new("theme/arrow_up.png"))
    	canvas:compose(665,380, canvas:new("theme/arrow_down.png"))

    -- Color de la fuente en la tabla de contenidos

    canvas:attrColor(0,0,0,256)

    end

   if color_categoria == "yellow" then

    -- Color de la fuente en la tabla de contenidos

    	canvas:attrColor(0,0,0,256)
    -- Configuración de las coordenadas de los elementos de acuerdo al color seleccionado

	posicion_columna_texto = 265
	separacion_filas=1.6
	inicio_columna=190

    -- Pinta el Fondo de la Tabla de Contenidos de Calendario

        canvas:compose(235,260, canvas:new("theme/bg_tabla_calendario.png"))

    -- Pinta las Flechas Arria y Abajo para la Navegación

        canvas:compose(665,300, canvas:new("theme/arrow_up.png"))
        canvas:compose(665,380, canvas:new("theme/arrow_down.png"))

   end


    if color_categoria == "blue" then

	-- Color de la fuente en la tabla de contenidos

	canvas:attrColor(0,0,0,256)

	-- Pinta el Fondo de la Tabla de Contenidos de Noticias

	--canvas:compose(45,240, canvas:new("theme/bg_tabla_noticias.png"))

	-- Pinta las Flechas Arria y Abajo para la Navegación

	canvas:compose(360,325, canvas:new("theme/arrow_up.png"))
	canvas:compose(360,460, canvas:new("theme/arrow_down.png"))
	canvas:compose(25,350, canvas:new("theme/arrow_left.png"))
	canvas:compose(665,350, canvas:new("theme/arrow_right.png"))

        -- Configuración de las coordenadas de los elementos de acuerdo al color seleccionado

	posicion_columna_texto = 290
	separacion_filas=1.5
	inicio_columna=5



	end
--**************************** Dibujar la Descripción  ********************************  
    canvas:attrColor(0,0,0,256)
    canvas:attrFont("Tiresias", 14)

    texto_descripcion=#elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].descripcion			  

    for i = indice_palabras, texto_descripcion, 1 do
      texto=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].descripcion[i].words
          col=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].descripcion[i].col
          row=elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].descripcion[i].row 
       
      if row == 0 then
         indice_elemento=indice_elemento+separacion_filas
      end
    
      if indice_elemento <= 12 then
         canvas:drawText(posicion_fila_texto+row+inicio_columna, posicion_columna_texto+col*indice_elemento,texto)
         
           if palabras_pagina < texto_descripcion and boton ~="u"then  
                 palabras_pagina=palabras_pagina+1, -1
              end
          end        
    end
     
    if palabras_pagina == texto_descripcion and final_pagina == "NO" and boton ~="u" then 
        final_pagina = "SI"
    pagina[indice_pagina]=palabras_pagina
    indice_final_pagina=indice_pagina
    end

    if palabras_pagina == texto_descripcion and final_pagina == "SI" and boton ~="u" and boton ~="d" then 
       indice_final_pagina=indice_pagina -1
    end
    
--**************************** Dibujar Imagen  ******************************* 
       
  if color_categoria == "blue" then
    imagen_elemento = canvas:new("media/" .. elementos.category[color_categoria].rss[indice_rss].channel.item[indice_elementos].imagen) 
    --canvas:compose(posicion_fila_imagen, posicion_columna_imagen, imagen_elemento)
    canvas:compose(posicion_fila_imagen, posicion_columna_imagen, imagen_elemento)
    canvas:flush()
  else
    canvas:flush() 
  end

	
end

--************************************************************************************  
--*                          Bloque Principal de la Aplicación                       *     
--************************************************************************************

Leer_elementos(color_categoria)
Pintar_Fondo_elemento(color_categoria)
Pintar_Elementos_Aplicacion(boton_inicial)
event.register(Eventos_Aplicacion)
