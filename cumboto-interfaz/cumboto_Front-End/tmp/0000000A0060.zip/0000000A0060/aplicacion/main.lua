--[[
__autor__   = "Yngris Ibargüen"
__email__   = "zyngris@gmail.com"
__date__    = "2015-05-10"
__version__ = "beta-0.2"
__license__ = "GPLv2"
]]


--Variables Globales

local indice_final_pagina=0
local indice_palabras_final=0
local pagina={}
local final_pagina = "NO"
local indice_pagina=0
local palabras_pagina=0
local indice_palabras=1
local indice_titulo=1
local indice_noticia= 1
local boton_inicial="r"
local contador_noticias = 0
local indice_rss = 0
local indice_noticias = 0
local posicion_fila_texto = 60
local posicion_columna = 135
local color_categoria = "red"
local posicion_fila_imagen = 417
local posicion_columna_imagen = 307.5
local col=0
local row=0
local texto=""



--********************************* Funciones de la Aplicación ************************************* 

-- Función para limpiar la pantalla.

function Limpiar_Pantalla()
    canvas:attrColor(0,0,0,0)
    canvas:clear(20, 190,349,310) --limpia la noticia
    canvas:clear(369, 279,332 ,220) -- limpia la imagen
end


-- Función para leer y decodificar las secuencias de escape del texto con json.

function Leer_Noticias()
       
    local json = require("json")
    local data = require("data")
        
    noticias = json.decode(data.FEEDS)
end

-- Función para pintar el fondo de la aplicación de acuerdo al color seleccionado.

function Pintar_Fondo_Noticia(color)
    
    canvas:attrColor(0,0,0,0)
    canvas:clear(20, 147,350 ,43)
    
    canvas:attrFont("Tiresias", 20, "bold")
    if color == "red" then 
        canvas:attrColor(164,0,27,255)
        canvas:drawText(50, 162 , noticias.config.category.rojo)
    end
    if color == "green" then 
        canvas:attrColor(0,144,56,255)
        canvas:drawText(50, 162 , noticias.config.category.verde)
    end
    if color == "yellow" then 
        canvas:attrColor(228,172,5,255)
        canvas:drawText(50, 162 , noticias.config.category.amarillo)
    end
    if color == "blue" then 
        canvas:attrColor(0,77,174,255)
        canvas:drawText(50, 162 , noticias.config.category.azul)
    end
    
    canvas:flush()
end

--Función para la ejecución de los eventos en la aplicación de acuerdo a la teclas pulsadas.

function Eventos_Aplicacion(boton)

    if boton.class=="ncl" and boton.type=="attribution" then

        
	if boton.value == "up" then
            Pintar_Elementos_Aplicacion("u")
        end 

        if boton.value == "down" then
            Pintar_Elementos_Aplicacion("d")
	      
	end 
        if boton.value == "left" then
            Pintar_Elementos_Aplicacion("l")
        end 

        if boton.value == "right" then
            Pintar_Elementos_Aplicacion("r")
        end 
        
	

        if boton.value == "red" or boton.value == "green" or boton.value == "yellow" or boton.value == "blue" then
            Pintar_Fondo_Noticia(boton.value)
            color_categoria = boton.value
            contador_noticias = 0
            indice_rss = 1
            indice_noticias = 1
	    indice_titulo=1
	    indice_noticia=1
	    indice_palabras=1
	    indice_pagina=0
	    palabras_pagina=0
	    indice_final_pagina=0 	
	    final_pagina = "NO"	
	    Pintar_Elementos_Aplicacion(boton.value)
        end 
    end 
end


--Función para pintar los elementos en la interfaz de la aplicación.


function Pintar_Elementos_Aplicacion(boton)
    

    if noticias.category[color_categoria] then
        contador_noticias = #noticias.category[color_categoria].rss
    else
        Limpiar_Pantalla()
        canvas:attrColor(0,0,0,255)
        canvas:attrFont("Tiresias", 14, "bold")
        canvas:drawText(posicion_fila_texto, posicion_columna + 45, "La categoría seleccionada no contiene noticias...")
        image = canvas:new("media/0.jpg") 
        canvas:compose(posicion_fila_imagen, posicion_columna_imagen, imagen_noticia)
        canvas:flush()
        return
    end
    
    if contador_noticias > 0 then
        if indice_rss == 0 then 
            indice_rss = 1
        end
    else
        return
    end
    
    if boton == "r" then
        final_pagina = "NO"
	palabras_pagina=0
	indice_pagina=0
	indice_palabras=1
        indice_titulo=1
	indice_noticia= 1
	indice_final_pagina=0
        if (indice_noticias + 1) <= #noticias.category[color_categoria].rss[indice_rss].channel.item then
            indice_noticias = indice_noticias + 1
        else
            if (indice_rss + 1) <= contador_noticias then
                indice_rss = indice_rss + 1
                indice_noticias = 1
            end
        end
    end  
 

    if boton == "l" then
        final_pagina = "NO"
        palabras_pagina=0
	indice_pagina=0
	indice_palabras=1 	
	indice_titulo=1
	indice_noticia=1
	indice_final_pagina=0     
	
	if (indice_noticias - 1) <= #noticias.category[color_categoria].rss[indice_rss].channel.item and (indice_noticias - 1) > 0 then
            indice_noticias = indice_noticias - 1
        else
            if (indice_rss - 1) <= contador_noticias and (indice_rss - 1) > 0 then
                indice_rss = indice_rss - 1
                indice_noticias = #noticias.category[color_categoria].rss[indice_rss].channel.item
            end
        end
    end
    
   
    if boton == "u" then
        indice_noticia=1	
	indice_titulo=1
        if indice_pagina - 1 > 0 then
           indice_palabras=pagina[indice_pagina-1] + 1
        end	
            
        if indice_pagina > 0 then
           indice_pagina=indice_pagina-1
        end    
        if  indice_pagina == 0 then
	     indice_palabras=1
             palabras_pagina=0
        end
    end 
    
    if boton == "d" then
        
        indice_noticia=1	
        indice_titulo=1
        
	if indice_pagina  < indice_final_pagina then
          indice_pagina=indice_pagina + 1 
          indice_palabras=pagina[indice_pagina] + 1
        end  	
                 
        if palabras_pagina < texto_descripcion and final_pagina == "NO" then
           indice_pagina=indice_pagina + 1
           pagina[indice_pagina]=palabras_pagina
           indice_palabras=pagina[indice_pagina] + 1
           indice_palabras_final=palabras_pagina + 1
        end
        
       if  indice_pagina == indice_final_pagina then
            indice_palabras=indice_palabras_final
       end
     
    end

--********************************* Dibujar el titulo de la Noticia **************************      

    Limpiar_Pantalla()
    canvas:attrColor(0,0,0,255)
    canvas:attrFont("Tiresias", 16, "bold")
    
    for i = 1, #noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].titulo, 1 do
	    posicion_columna_texto = posicion_columna + 45
	    texto=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].titulo[i].words
      	    col=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].titulo[i].col
            row=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].titulo[i].row 		  
	  
	  if row == 0 then
	    indice_titulo=indice_titulo+1 
          end
          canvas:drawText(posicion_fila_texto+row+5, posicion_columna_texto+col*indice_titulo,texto)
    end

--********************************* Dibujar la Fecha de la Noticia ********************************      
   
    posicion_columna_texto = posicion_columna_texto + 90
    canvas:attrFont("Tiresias", 12)
    canvas:drawText(posicion_fila_texto+5, posicion_columna_texto, noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].fecha)


--**************************** Dibujar la Descripción de la Noticia ********************************	
    
    canvas:attrFont("Tiresias", 13)
    posicion_columna_texto = 260
    texto_descripcion=#noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].descripcion
    	
    for i = indice_palabras, texto_descripcion, 1 do
	  texto=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].descripcion[i].words
      	  col=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].descripcion[i].col
          row=noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].descripcion[i].row 
	   
	  if row == 0 then
	     indice_noticia=indice_noticia+1
	  end
	
	  if indice_noticia <= 12 then
	     canvas:drawText(posicion_fila_texto+row+5, posicion_columna_texto+col*indice_noticia,texto)
	     
	       if palabras_pagina < texto_descripcion and boton ~="u"then  
                 palabras_pagina=palabras_pagina+1, -1
              end
          end        
    end
     
    if palabras_pagina == texto_descripcion and final_pagina == "NO" and boton ~="u" then 
        final_pagina = "SI"
	pagina[indice_pagina]=palabras_pagina
	indice_final_pagina=indice_pagina
    end

    if palabras_pagina == texto_descripcion and final_pagina == "SI" and boton ~="u" and boton ~="d" then 
       indice_final_pagina=indice_pagina -1
    end


--**************************** Dibujar Imagen de la Noticia *******************************	

      imagen_noticia = canvas:new("media/" .. noticias.category[color_categoria].rss[indice_rss].channel.item[indice_noticias].imagen) 
      canvas:compose(posicion_fila_imagen, posicion_columna_imagen, imagen_noticia)
      canvas:flush()
    
   end

--************************************************************************************	
--*                          Bloque Principal de la Aplicación                       *     
--************************************************************************************

Leer_Noticias()
Pintar_Fondo_Noticia("red")
Pintar_Elementos_Aplicacion(boton_inicial)
event.register(Eventos_Aplicacion)
