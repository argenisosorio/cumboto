require 'src.FrameworkConfig'
require 'src.StagesLoader'
require 'src.Modules'

--START FRAMEWORK CORE
FiniteStateMachine:Init()
EventManager:Init()
Engine:Init()

--EXECUTE CONFIGURATION
configFramework()
loadStages()

--START APPLICATION
FiniteStateMachine:start()