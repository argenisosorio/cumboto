--- Stage Abstract Class
module ('Stage', package.seeall)

Stage = {
  -- Instance Atributes
}
setmetatable(Stage,Object)
Stage.super   = Object
Stage.__index = Stage
_G.Stage      = Stage

--- Class initialization method
function Stage:Init()
  print('[DEBUG]{ABSTRACT-Stage} - INIT')
  -- Instance Atributes Initialization
end

--- show() method.
function Stage:show()
  -- Subclass responsability  
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-Display)-SHOW')
end

--- hide() method.
function Stage:hide()
  -- Subclass responsability  
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-Display)-HIDE')
end

--- redPressed() method.
function Stage:redPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-RED')
end

--- greenPressed() method.
function Stage:greenPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-GREEN')
end

--- yellowPressed() method.
function Stage:yellowPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-YELLOW')
end

--- bluePressed() method.
function Stage:bluePressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-BLUE')
end

--- menuPressed() method.
function Stage:menuPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-MENU')
end

--- infoPressed() method.
function Stage:infoPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-INFO')
end

--- upPressed() method.
function Stage:upPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-UP')
end

--- downPressed() method.
function Stage:downPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-DOWN')
end

--- rightPressed() method.
function Stage:rightPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-RIGHT')
end

--- leftPressed() method.
function Stage:leftPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-LEFT')
end

--- enterPressed() method.
function Stage:enterPressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-ENTER')
end

--- number0Pressed() method.
function Stage:number0Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 0')
end

--- number1Pressed() method.
function Stage:number1Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 1')
end

--- number2Pressed() method.
function Stage:number2Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 2')
end

--- number3Pressed() method.
function Stage:number3Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 3')
end

--- number4Pressed() method.
function Stage:number4Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 4')
end

--- number5Pressed() method.
function Stage:number5Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 5')
end

--- number6Pressed() method.
function Stage:number6Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 6')
end

--- number7Pressed() method.
function Stage:number7Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 7')
end

--- number8Pressed() method.
function Stage:number8Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 8')
end

--- number9Pressed() method.
function Stage:number9Pressed()
  -- Subclass responsability
  print('[DEBUG]{ABSTRACT-Stage}(UNIMPLEMENTED-KeyEvent)-NUMBER 9')
end


--- This method must be implemented if EditingCommand is used (write media property)
function Stage:updateData()
  -- Update stage view. Used for editing Command
end