--- Abstract Class Widget
module ('Widget', package.seeall)

Widget = {
 -- Instance Atributes
 x      = 0,
 y      = 0,
 width       = 0,
 height      = 0,
 container   = nil,
 is_loaded   = nil,
 is_saved    = false,
 visible     = nil,
 load_event  = nil,
 has_changed = false,
 in_load_queue = false,
 in_render_queue = false,
 memory_used = 0
}
setmetatable(Widget,Object) --Hereda de Object
Widget.super   = Object
Widget.__index = Widget  --Se prepara Widget para ser Heredada
_G.Widget      = Widget   --Se publica Widget en el entorno global

--- Abstract construnctor
-- @param x position
-- @param y position
function Widget:Init(x,y)
 self.x     = x
 self.y     = y
 self.is_loaded  = false
 self.visible    = true
 self.load_event = SimpleEvent:new()
end

--ACCESSORS
--- Set container
-- @param aContainer widget
-- @param is_saved boolean
function Widget:setContainer(aContainer,is_saved)
  print("[DEBUG]WIDGET - CHANGED CONTAINER:",self.container,"to:",aContainer, self)
  if self.container ~=nil then
    self.container:removeWidget(self)
  end
  self.container = aContainer
  self.is_saved  = is_saved
end

--- Get Bounds (the position x&y and the width and height) of the widget. Used primarly on Tools:Clear()
-- @return  x,y,width,height (number)
function Widget:getBounds()
  return self:getX(),self:getY(),self:getWidth(),self:getHeight()
end

--- Get position x
-- @return x position (number)
function Widget:getX()
  return self.x 
end

--- Get position y
-- @return y position (number)
function Widget:getY()
  return self.y
end

--- Set position x,y of the widget
-- @param x number
-- @param y number
function Widget:setPos(x,y)
  if self.container then self.container:changed(self) end
  self.x = x
  self.y = y
end

--- Set position x of the widget
-- @param value number
function Widget:setX(value)
  print("[DEBUG]WIDGET - CHANGED POSX", self)
  if self.container then self.container:changed(self) end
  self.x = value
end

--- Set position y
-- @param value number
function Widget:setY(value)
  print("[DEBUG]WIDGET - CHANGED POSY", self)
  if self.container then self.container:changed(self) end
  self.y = value
end

--- Get width size
-- @return width size (number)
function Widget:getWidth()
  return self.width
end

--- Set width size
-- @param value number
function Widget:setWidth(value)
  if self.container then self.container:changed(self) end
  self.width = value
end

--- Get height size
-- @return width size (number)
function Widget:getHeight()
  return self.height
end

--- Set height size
-- @param value number
function Widget:setHeight(value)
  if self.container then self.container:changed(self) end
  self.height = value
end

--- Set visible value of widget
-- @param aBoolean boolean
function Widget:setVisible(aBoolean)
  print("[DEBUG]WIDGET - CHANGED VISIBILITY", self)
  self.visible = aBoolean
  if (not self.visible) then
    Tools:clear(self.container.canvas, self:getBounds())
  else
    self.container:changed(self)
  end
end

function Widget:clone()
  return nil
end

--- Toggle visibility of widget
-- @param aBoolean boolean
function Widget:toggleVisible()
  self:setVisible(not self.visible)
end

--- Get visibility value
-- @return boolean
function Widget:getVisible()
  return self.visible
end

--- Draw widget in screen
function Widget:draw()
  --subclass responsability
end

function Widget:memoryUsage()
  return 0
end

function Widget:load()
  print('[DEBUG]{ABSTRACT}WIDGET-LOAD', self)
  --subclass responsability
  self.is_loaded = true
  self.load_event:dispatch(self)
end

