module ('SimpleEvent', package.seeall)

SimpleEvent = {
  --Class Atributes
  --Instance Atributes
  listeners   = nil
}

setmetatable(SimpleEvent,Object)
SimpleEvent.super   = Object
SimpleEvent.__index = SimpleEvent
_G.SimpleEvent      = SimpleEvent

function SimpleEvent:Init()
  self.listeners = {}
end

--Instance Methods
--- Add Listener
-- @param method method or function from an object.
-- @param object listener object.
function SimpleEvent:addListener(method,object)
  self.listeners[object] = method
end

--- Remove Listener
-- @param method method or function from an object.
-- @param object listener object.
function SimpleEvent:removeListener(method,object)
  self.listeners[object] = nil
end

--- Dispatch sender
-- @param sender.
function SimpleEvent:dispatch(sender)
  for i,v in pairs(self.listeners) do
    if (v) then v(i,sender); end
  end
end