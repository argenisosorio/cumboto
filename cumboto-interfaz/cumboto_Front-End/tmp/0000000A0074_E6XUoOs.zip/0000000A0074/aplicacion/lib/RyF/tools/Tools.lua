--- Module Tools
module ('Tools', package.seeall)

Tools = {}
_G.Tools = Tools


--- Return ocurrences in tables width match pattern
-- @param tbl table
-- @param pattern string
function Tools:countOcurrences(tbl, pattern)
-- retorna cantidad de veces que aparece pattern en tbl
  local tot=0
  for i,each in pairs(tbl) do
    if each==pattern then
      tot=tot+1
    end
  end
  return tot
end 

--- Split string
-- @param str string
-- @param pattern string
-- @return table with ocurrences of the pattern
function Tools:split(str, pattern)
    local res = {}
    for w in str:gmatch('[^'..pattern..']+') do
            res[#res + 1] = w
    end
    return res
end

--- Return the Heigth of aCanvas
-- @param aCanvas canvas object
-- @return number
function Tools:getCanvasHeight(aCanvas)
  local cv = aCanvas or canvas
  local w,h = cv:attrSize()
  return h
end

--- Return the Width of aCanvas
-- @param aCanvas canvas object
-- @return number
function Tools:getCanvasWidth(aCanvas)
  local cv = aCanvas or canvas
  local w,h = cv:attrSize()
  return w
end

--- Return the width and height from string
-- @param aString string
-- @param fontName font name
-- @param size font size
-- @return width,height (numbers)
function Tools:measureText(aString,fontName,size,style)
  if Engine.GINGA2 then
    local oldR,oldG,oldB,oldA = canvas:attrColor()
    canvas:attrColor("black")
    canvas:attrFont(fontName or "Tiresias",size or 14,style or 'bold')
    local width,height = canvas:measureText(aString)
    canvas:attrColor(oldR,oldG,oldB,oldA)
    return width,height
  else
    --TODO
	return 0,0
  end
end

function Tools:measureTextWidth(aString,fontName,size)
  local width,height = self:measureText(aString,fontName,size)
  return width
end

function Tools:measureTextHeight(aString,fontName,size)
  local width,height = self:measureText(aString,fontName,size)
  return height
end

--- Encode UNICODE text to UTF8
-- @param aCanvas canvas object
-- @param x x position
-- @param y x position
-- @param w width size
-- @param h height size
function Tools:clear(aCanvas,x,y,w,h)
-- THIS #Clear() WORKS EVEN IF THE ZONE TO CLEAR GOES BEYOND THE CANVAS  
  local cw,ch = aCanvas:attrSize()
  local rw,rh = w,h
  if x+w > cw then rw = cw - x end
  if y+h > ch then rh = ch - y end
  if Engine.GINGA2 then
    aCanvas:clear(x,y,rw,rh)
  else
    local r,g,b,a = canvas:attrColor()
    canvas:attrColor(0,0,0,0)
    canvas:drawRect('fill',x,y,rw,rh)
    canvas:attrColor(r,g,b,a)
  end
end

--- Encode UNICODE text to UTF8
-- @param txt string
-- @return utf8 text
function Tools:unicodeToUTF8(txt)
  local from = 1
  local unic = string.find(txt,'\u00')
  local i,toreplace
  while unic do
    i = tonumber(string.sub(txt,unic+1,unic+4),16)
    toreplace = string.sub(txt,unic-1,unic+4)    
    txt  = string.gsub(txt,toreplace,unicode_table[i+1],1)
    unic = string.find(txt,'\u00',from)
    from = unic
  end
  return txt
end