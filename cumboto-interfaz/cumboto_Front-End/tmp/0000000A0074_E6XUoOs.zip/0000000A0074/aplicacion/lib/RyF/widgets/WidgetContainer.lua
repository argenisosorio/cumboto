--- Abstract Class Widget
module ('WidgetContainer', package.seeall)

WidgetContainer = {
  widgets               = nil,
  img_path              = nil,
  canvas                = nil,
  render_pipe           = nil,
  widgets_to_load       = nil,
  widgets_to_load_index = nil,
  load_timer            = nil,
  load_finish_event     = nil,
  already_loaded        = false
}

setmetatable(WidgetContainer,Widget)
WidgetContainer.super   = Widget
WidgetContainer.__index = WidgetContainer
_G.WidgetContainer      = WidgetContainer

--- Class WidgetContainer construnctor
-- @param x position
-- @param y position
-- @param img_path string
function WidgetContainer:Init(x,y,img_path)
  print("[DEBUG]WIDGET - CREATE CONTAINER", self,"POS:"..x..","..y.." Path:"..img_path)
  self.super.Init(self,x,y)
  --Instance Atributes Initialization
  self.img_path              = img_path
  self.widgets               = {}
  self.render_pipe           = {}
  self.widgets_to_load       = {}
  self.widgets_to_load_index = 1
  self.load_timer            = Timer:new(10)
  self.load_timer.timer_event:addListener(self.loadWidgets,self)
  self.load_finish_event     = SimpleEvent:new()
  self.load_finish_event:addListener(self.drawWidgets,self)
end

--- Draw widget Container
function WidgetContainer:draw()
  print ("[DEBUG]CONTAINER - DRAWING", self)
  self.container:compose(self.x,self.y,self.canvas)
end

--- Compose aCanvas in WidgetContainer canvas
-- @param x number 
-- @param y number
-- @param aCanvas canvas
function WidgetContainer:compose(x,y,aCanvas)
  self.canvas:compose(x,y,aCanvas)
end

--- Add widget to container
-- @param aWidget Widget Object
function WidgetContainer:addWidget(id,aWidget,store)
  if self.widgets[id] ~= nil then 
    self:removeWidget(id)
  end
  if store==nil then 
    store=true
  end
  print("[DEBUG]CONTAINER - ADDING WIDGET",aWidget,"CONT:",self, "Id: "..id, "Store:",store)
  aWidget:setContainer(self,store)
  if ((not aWidget.is_loaded)and (not aWidget.in_load_queue))then
    print("[DEBUG]CONTAINER - ADDED TO LOAD QUEUE")
    table.insert(self.widgets_to_load,aWidget);
    aWidget.in_load_queue = true
  end
  if (not aWidget.in_render_queue) then
    print("[DEBUG]CONTAINER - ADDED TO RENDER QUEUE")
    table.insert(self.render_pipe,aWidget) 
    aWidget.in_render_queue = true
  end
  if (store) then
    self.widgets[id] = aWidget
  end
  if (self.container) then 
    print("[DEBUG]CONTAINER - CHANGED", self)
    self.container:changed(self);
  end
  
end

--- drawWidgets container in screen
function WidgetContainer:drawWidgets()
  print("[DEBUG]CONTAINER - DRAWING WIDGETS","CONT:",self)
  print("[DEBUG]CONTAINER - WIDGETS TO DRAW", #self.render_pipe)
  for i,v in ipairs(self.render_pipe) do
    v:draw()
    v.has_changed=false
  end
  self.canvas:flush()
  self.load_event:dispatch(self)
end

--- Change status of aWidgets
-- @param aWidget Widget Object.
function WidgetContainer:changed(aWidget)
  if aWidget.has_changed then return; end
  print("[DEBUG]CONTAINER - WIDGET CHANGED",aWidget,"CONT:",self)
  if (self.clearOnChange and aWidget.is_loaded) then 
    Tools:clear(self.canvas,aWidget:getBounds())
  end
  if aWidget:getVisible() == false then return; end
  if (not aWidget.is_loaded) and (not aWidget.in_load_queue) then
    print("[DEBUG]CONTAINER - ADDED TO LOAD QUEUE")
    table.insert(self.widgets_to_load,aWidget);
    aWidget.in_load_queue = true
  end
  aWidget.has_changed = true
  if (not aWidget.in_render_queue) then
    print("[DEBUG]CONTAINER - ADDED TO RENDER QUEUE")
    table.insert(self.render_pipe,aWidget)
    aWidget.in_render_queue = true
  end
  self.container:changed(self)
end

function WidgetContainer:getClearOnChange()
  return self.container:getClearOnChange()
end

function WidgetContainer:load()
  self.canvas             = canvas:new(self.img_path)
  self.width,self.height  = self.canvas:attrSize()
  if (not self.already_loaded) then
    for i,v in pairs(self.widgets) do
      if (not v.is_loaded) and (not v.in_load_queue) then
        table.insert(self.widgets_to_load,v)
        v.in_load_queue = true
      end
      if (not v.in_render_queue) then
        table.insert(self.render_pipe,v)
        v.in_render_queue = true
      end
    end
    table.insert(self.render_pipe,v)
  end
  self:render()
  self.already_loaded = true
end

function WidgetContainer:render()
  print("[DEBUG]CONTAINER - STARTING LOADING WIDGETS","CONT:",self)
  self:loadWidgets()
end

--- Load all widgets from container widget list
function WidgetContainer:loadWidgets()
  if self.widgets_to_load_index <= #self.widgets_to_load then
    local currentIndex = self.widgets_to_load_index
    self.widgets_to_load_index = self.widgets_to_load_index+1
    self.widgets_to_load[currentIndex].load_event:addListener(self.startLoadWidgetTimer,self)
    self.widgets_to_load[currentIndex]:load()
  else
    self:onWidgetLoadEnd()
  end
end

--- Start the timer object to load widgets.
function WidgetContainer:startLoadWidgetTimer(sender)
  print("[DEBUG]CONTAINER - WIDGET LOADED",sender,"CONT:",self)
  sender.load_event:removeListener(self.startLoadWidgetTimer,self)
  sender.in_load_queue = false
  self.load_timer:startTimer()
end

--- Dispatch an event when end the load of the widgets
function WidgetContainer:onWidgetLoadEnd()
  print("[DEBUG]CONTAINER - ENDED LOADING WIDGETS","CONT:",self)
  self.widgets_to_load = {}
  self.widgets_to_load_index = 1
  self.is_loaded = true
  self.load_finish_event:dispatch(self)
end

--- Remove widget
-- @param id identifier.
function WidgetContainer:removeWidget(id)
  print("[DEBUG]CONTAINER - ADDING WIDGET",aWidget,"CONT:",self, "Id: "..id)
  self.widgets[id] = nil
end

--- Get widget
-- @param id identifier.
-- @return Widget Object.
function WidgetContainer:getWidget(id)
  return self.widgets[id]
end