--- Timer Class
module ('Timer', package.seeall)

Timer = {
  --Class Atributes
  
  --Instance Atributes
  delay         = 20,
  repeat_count  = 1,
  current_count = 0,
  running       = false,
  timer_event   = nil,
  stop_func     = nil
}

setmetatable(Timer,Object)   --Hereda de Object
Timer.super   = Object
Timer.__index = Timer  --Se prepara para ser Heredada
_G.Timer      = Timer  --Se publica en el entorno global

--- Class constructor
-- @param delay delay time.
-- @param repearCount number of repetitions.
function Timer:Init(delay,repeat_count)
  --Instance Atributes Initialization
  self.timer_event  = SimpleEvent:new()
  self.delay        = delay or 0
  self.repeat_count = repeat_count or 1
end

--- Start Timer method
function Timer:startTimer()
  self.current_count = 0
  if self.delay > 0 then
    self.stop_func = event.timer(self.delay,function() self:timerTick(); end)
  end
end

--- Stop Timer method
function Timer:stopTimer()
  self.stop_func()
end

function Timer:timerTick()
  self.timer_event:dispatch(self)
  self.current_count = self.current_count + 1
  if self.current_count < self.repeat_count then
    self.stop_func = event.timer(self.delay,function() self:timerTick(); end)
  end
end