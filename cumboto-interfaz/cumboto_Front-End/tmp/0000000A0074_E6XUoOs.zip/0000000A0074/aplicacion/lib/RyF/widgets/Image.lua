--- Class Image
module ('Image', package.seeall)

Image = {
 img   = nil,
 path  = ''
}
setmetatable(Image,Widget)
Image.super   = Widget
Image.__index = Image
_G.Image      = Image

--- Class Image construnctor
-- @param x position
-- @param y position
-- @param path string (path to image)
function Image:Init(x,y,path)
  print("[DEBUG]WIDGET - CREATE IMAGE", self,"POS:"..x..","..y.." Path:"..path)
  self.super.Init(self,x,y)
  self.path = path
end

--ACCESSORS
--- Load Image in memory.
function Image:load()
  self.img = canvas:new(self.path)
  print("[DEBUG] LOADING REAL", self.img)
  self.width,self.height = self.img:attrSize()
  self.is_loaded = true
  self.load_event:dispatch(self)
end

--- Return the path of the image.
-- @return path string
function Image:getPath()
  return self.path
end

--- Set the path of the image.
-- @param aPath The path used by the <a href="#">Image:load()</a> function.
function Image:setPath(aPath)
  self.path = aPath
  if self.container then
    self.container:changed()
  end
end

function Image:clone()
  local newWidget = Image:new(self.x,self.y,self.path)
  newWidget.img = self.img
  newWidget.container = self.container
  newWidget.is_loaded = self.is_loaded
  newWidget.width = self.width
  newWidget.height = self.height
  newWidget.load = function()
    newWidget.img = self.img
	print("[DEBUG] LOADING CLONE", newWidget.img)
    newWidget.width,newWidget.height = newWidget.img:attrSize();
    newWidget.is_loaded = true
    newWidget.load_event:dispatch(newWidget)
  end
  newWidget.memoryUsage = function()
    return 0
  end
  return newWidget
end

function Image:memoryUsage()
  return self.width*self.height*4
end

--- Draw the image in screen.
function Image:draw()
  print ("[DEBUG]IMAGE - DRAWING", self)
  self.container:compose(self.x,self.y,self.img)
end
