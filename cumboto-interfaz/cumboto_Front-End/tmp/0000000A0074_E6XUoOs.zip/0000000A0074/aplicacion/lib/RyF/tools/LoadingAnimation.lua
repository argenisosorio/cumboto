--- Module Loading Animation
module ('LoadingAnimation', package.seeall)

local running     = false --is the loading animation running?
local cancelFun   = nil     --function to call the timer off
local background  = canvas:new('resources/loadingImages/fondoLoading.png')
local backW,backH = background:attrSize()
local w,h = canvas:attrSize()
local xBackPos
local yBackPos

local positions = {
  [1] = function () xBackPos = 0; yBackPos=h-backH; end,
  [2] = function () xBackPos = (w/2)-(backW/2); yBackPos = h-backH; end,
  [3] = function () xBackPos = w-backW; yBackPos = h-backH; end,
  [4] = function () xBackPos = 0; yBackPos = (h/2)-(backH/2); end,
  [5] = function () xBackPos = (w/2)-(backW/2); yBackPos = (h/2)-(backH/2); end,
  [6] = function () xBackPos = w-backW; yBackPos = (h/2)-(backH/2); end,
  [7] = function () xBackPos = 0; yBackPos = 0; end,
  [8] = function () xBackPos = (w/2)-(backW/2); yBackPos = 0; end,
  [9] = function () xBackPos = w-backW; yBackPos = 0; end
 }

local images={
  canvas:new('resources/loadingImages/FRAME_000001.png'),
  canvas:new('resources/loadingImages/FRAME_000002.png'),
  canvas:new('resources/loadingImages/FRAME_000003.png'),
  canvas:new('resources/loadingImages/FRAME_000004.png'),
  canvas:new('resources/loadingImages/FRAME_000005.png'),
  canvas:new('resources/loadingImages/FRAME_000006.png'),
  canvas:new('resources/loadingImages/FRAME_000007.png'),
  canvas:new('resources/loadingImages/FRAME_000008.png')
}
local imageIndex=1
local currentImage= images[imageIndex]

function update(number)
  if running == true then
    imageIndex = math.floor(#images*number)
    draw()
  end
end

--- set background image
function setBackground(new_background)
  background  = new_background
  backW,backH = background:attrSize()
end

--- set list of images
function setImages(new_images)
  images = new_images
end

--- set position in the screen
-- @param pos number value (1-9)
function setAnimPos(pos)
  positions[pos]();
end

--- set position in the screen
-- @param x number
-- @param y number
function setFixedAnimPos(x,y)
  xBackPos=x
  yBackPos=y
end

function draw()
  if imageIndex < 1 then 
    imageIndex = 1 
  end
  currentImage = images[imageIndex]
  --compose the currentframe of the animation
  canvas:compose(xBackPos+12,yBackPos+4,currentImage)
  canvas:flush()
end

--- start animation
function start()
  --create background image
  --compose the background
  canvas:compose(xBackPos,yBackPos,background)
  canvas:flush()
  --draw the current frame of animation
  draw()
  running = true
end

--- stop animation
function stop()
  if (running) then
    Tools:clear(canvas,xBackPos,yBackPos,backW,backH)
    running = false
  end
end

--- return true or false
function isRunning()
  return running
end