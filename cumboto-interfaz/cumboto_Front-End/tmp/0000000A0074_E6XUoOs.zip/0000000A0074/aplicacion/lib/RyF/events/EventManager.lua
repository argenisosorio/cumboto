--- Event Manager Module
module ('EventManager', package.seeall)

EventManager = {
 -- Class Attributes
 timeDelay   = 40,
 can_process = true,
 key         = '',
}
_G.EventManager = EventManager


function EventManager:Init()
  -- Instance Attributes Initialization
  self.map  = {
    RED         = function() self._stage:redPressed()    end,
    BLUE        = function() self._stage:bluePressed()   end,
    GREEN       = function() self._stage:greenPressed()  end,
    YELLOW      = function() self._stage:yellowPressed() end,
    MENU        = function() self._stage:menuPressed()   end,
    INFO        = function() self._stage:infoPressed()   end,
    CURSOR_UP   = function() self._stage:upPressed()     end,
    CURSOR_DOWN = function() self._stage:downPressed()   end,
    CURSOR_RIGHT= function() self._stage:rightPressed()  end,
    CURSOR_LEFT = function() self._stage:leftPressed()   end,
    OK          = function() self._stage:enterPressed()  end,

    NUMBER1 = function() self._stage:number1Pressed()    end,
    NUMBER2 = function() self._stage:number2Pressed()    end,
    NUMBER3 = function() self._stage:number3Pressed()    end,
    NUMBER4 = function() self._stage:number4Pressed()    end,
    NUMBER5 = function() self._stage:number5Pressed()    end,
    NUMBER6 = function() self._stage:number6Pressed()    end,
    NUMBER7 = function() self._stage:number7Pressed()    end,
    NUMBER8 = function() self._stage:number8Pressed()    end,
    NUMBER9 = function() self._stage:number9Pressed()    end,
    NUMBER0 = function() self._stage:number0Pressed()    end,    
    
    F1  = function() self._stage:redPressed()    end,
    F4  = function() self._stage:bluePressed()   end,
    F2  = function() self._stage:greenPressed()  end,
    F3  = function() self._stage:yellowPressed() end,
    F5  = function() self._stage:menuPressed()   end,
    F6  = function() self._stage:infoPressed()   end,
    ENTER  = function() self._stage:enterPressed()  end,
  }

  self.handlerKey = function(evt) self:keyEventHandler(evt) end
  self.handlerEDC = function(evt) self:EDCEventHandler(evt) end
  event.register(self.handlerKey)
end

--- Handler from key events
-- @param evt key event.
function EventManager:keyEventHandler(evt)
  if evt.class == 'key' and   evt.type=='press'then
    self:dispatchPressedKeyEvent(evt)
  end
end


function EventManager:attributionEventDispatch(action, property, value)
  return  event.post('out',{class = "ncl", type = "attribution", name = property, action=action, value=value})
end

--- Distpatch event for property media attribution.
-- @param property name of the property to dispatch the value param.
-- @param value value to dispatch.
function EventManager:dispatchEvent(property, value)
  self:attributionEventDispatch('start', property, value)
  self:attributionEventDispatch('stop',  property, value)
end

--- Set the stage from this Event Manager.
-- @param stage the Event Manager will send events to this stage.
function EventManager:setStage(stage)
  print("[DEBUG] EventManager setStage")
  self.can_process = (stage ~= nil)
  self._stage = stage
end

function EventManager:process_key()
  print(self._key.key)
  if self.map[self._key.value] then --class attribution
    self.map[self._key.value]() 
  elseif self.map[self._key.key] then --class key
    self.map[self._key.key]()
    --fix ginga <= 1.2 en STB's
  elseif (tonumber(self._key.key) ~= nil) and self.map['NUMBER'..self._key.key] then
    self.map['NUMBER'..self._key.key]()
  elseif (tonumber(self._key.value) ~= nil) and self.map['NUMBER'..self._key.value] then
    self.map['NUMBER'..self._key.value]()    
  end
    self.can_process = true
end

function EventManager:dispatchPressedKeyEvent(evt)
  if self.can_process then
    self.can_process = false
    self._key = evt
    event.timer(self.timeDelay,function() self:process_key(); end)
  end
end

--- Enable listen key events
function EventManager:enableKeys()
  self.can_process = true
end

--- Disable listen key events
function EventManager:disableKeys()
  self.can_process = false
end

-- EDITING COMMAND !!!

--- Enable listen Editing Command events
function EventManager:enableEDC()
    event.register(self.handlerEDC)
end

--- Enable listen Editing Command events
function EventManager:disableEDC()
    event.unregister(self.handlerEDC)
end

--- Set configuration file for Editing Command
-- @param configuration configuration file
function EventManager:setConfigurationEDC(configuration)
  require (configuration)
end

function EventManager:decodeEDC(forListener,value)
  EditingCommand:decode(forListener,value)
  self._stage:updateData()
  self.can_process  = true
end

--- Handler from Editing Command
-- @param evt Editing Command events.
function EventManager:EDCEventHandler(evt)
  if evt.class == 'ncl' and evt.type=='attribution' and EditingCommand:canProcess(evt.name) then
    if self.can_process then
      self.can_process = false
      event.timer(self.timeDelay,function() self:decodeEDC(evt.name,evt.value); end)
    end
  end
end