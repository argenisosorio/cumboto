--- Class Text
module ('Text', package.seeall)

Text = {
  text      = '',
  color     = 'white',
  size      = 14,
  style     = 'bold',
  font_name = 'Tiresias',
  padding   = 'left',
  text_canvas = nil
}

setmetatable(Text,Widget)
  Text.super   = Widget
  Text.__index = Text
  _G.Text      = Text

--- Class Text constructor
-- @param x position
-- @param y position
-- @param text string
-- @param padding string ('left','center','right')
-- @param color string
-- @param size number
-- @param style string
-- @param font_name string
function Text:Init(x,y,text,padding,color,size,style,font_name)
  print("[DEBUG]WIDGET - CREATE TEXT", self,"POS:"..x..","..y.." Text:"..text)
  Widget.Init(self,x,y)
  self.color     = color or 'white'
  self.size      = size or 14
  self.style     = style or 'bold'
  self.font_name = font_name or 'Tiresias'
  self.padding   = padding or 'left'
  self:setText(text)
  if (padding=='center') then 
    self:centerOn(x,y)
  else 
    if (padding=='right') then 
      self:rightOn(x,y)
    end
  end
end

--ACCESSORS
--- Get the text of the widget
-- @return string
function Text:getText()
  return self.text
end

--- Set text
-- @param aText string
function Text:setText(aText)
  self.text = aText
  self.width, self.height = Tools:measureText(self.text,self.font_name,self.size,self.style)
  if (self.container) then self.container:changed(self) end
end

function Text:clone()
  local newWidget = Text:new(self.x,self.y,self.text,self.padding,self.color,self.size,self.style,self.font_name)
  newWidget.container = self.container
  newWidget.is_loaded = self.is_loaded
  return newWidget
end

--- Get Vertical Padding of text Widget (NOT WORKING AT THE MOMENT)
-- @return vertical Padding value in number.
function Text:getVPadding()
  return self.vPadding
end

--- Set Vertical Padding of text Widget (NOT WORKING AT THE MOMENT)
-- @param aValue value in number.
function Text:setVPadding(aValue)
  self.vPadding = aValue
  self.container:changed(self)
end

--- Get Size of text Widget
-- @return size value in number.
function Text:getSize()
  return self.size
end

--- Set Size of text Widget
-- @param aValue value in number.
function Text:setSize(aValue)
  self.size = aValue
  self.container:changed(self)
end

--- Get Color of text Widget
-- @return Color value in number.
function Text:getColor()
  return self.color
end

--- Set Color of text Widget
-- @param aColor value in number defined for ABNT
function Text:setColor(aColor)
  self.color = aColor
  self.container:changed(self)
end

--- Center widget in x,y positions
-- @param x x position
-- @param y y position
function Text:centerOn(x,y)
  self.x = x - self.width/2
  self.y = y - self.height/2
end

--- Set widget to right of x,y positions
-- @param x x position
-- @param y y position
function Text:rightOn(x,y)
  self.x = x - self.width
  self.y = y
end

--- Draw widget in screen
function Text:draw()
  print ("[DEBUG]TEXT - DRAWING", self)
  local oldR,oldG,oldB,oldA = self.container.canvas:attrColor()
  self.container.canvas:attrColor(self.color)
  self.container.canvas:attrFont(self.font_name,self.size,self.style)
  self.container.canvas:drawText(self.x,self.y,self.text)
  self.container.canvas:attrColor(oldR,oldG,oldB,oldA)
end
