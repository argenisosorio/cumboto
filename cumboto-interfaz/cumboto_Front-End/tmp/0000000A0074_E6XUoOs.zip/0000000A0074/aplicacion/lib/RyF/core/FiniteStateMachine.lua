--- Module Finite State Machine
module ('FiniteStateMachine', package.seeall)

FiniteStateMachine = {
  current_stage          = nil,
  state_transition_table = {},
  initial_stage          = nil
}

_G.FiniteStateMachine    = FiniteStateMachine

--- Module initialization method
function FiniteStateMachine:Init()
  print("[DEBUG]FSM - INIT")
  self.state_transition_table['Global'] = {}
end

--- Change to aStage
-- @param aStage Stage instance.
function FiniteStateMachine:changeStageTo(aStage)
  self.current_stage = aStage
  print("[DEBUG]FSM - SETTING EVENT MANAGER TO:",self.current_stage)
  EventManager:setStage(self.current_stage)  
end

--- Start method, change to initial Stage
---@see FiniteStateMachine:setInitialStage(aStage)
function FiniteStateMachine:start()
  print("[DEBUG]FSM - STARTING APP")
  self:changeStageTo(self.initial_stage)
  Engine:render()
end

--- Set the initial Stage
--- @param aStage Stage Object
function FiniteStateMachine:setInitialStage(aStage)
  print("[DEBUG]FSM - SET INITIAL STAGE ",aStage)
  self.initial_stage = aStage
end

--- Add Transitions to FiniteStateMachine.
--- @param fromStage Stage instance.
--- @param toStage Stage instance.
--- @param idTransition string.
--- @usage  FiniteStateMachine:addTransition(redStage,greenStage,'redToGreen')
function FiniteStateMachine:addTransition(fromStage,toStage,idTransition)
  print("[DEBUG]FSM - ADDING TRANSITION","ID:"..idTransition,"FROM:",fromStage,"TO:",toStage)
  if (self.state_transition_table[fromStage] == nil) then
    self.state_transition_table[fromStage] = {}
  end
  self.state_transition_table[fromStage][idTransition] = function () return toStage end
end

--- Define global transition
--- @param idTransition identifier from transition
--- @param toStage Stage Object
--- @usage  FiniteStateMachine:addGlobalTransition('toGreen',RedStage)
function FiniteStateMachine:addGlobalTransition(idTransition,toStage)
  print("[DEBUG]FSM - ADDING GLOBAL TRANSITION","ID:"..idTransition,"TO:",toStage)
  self:addTransition('Global',toStage,idTransition)
end

--- Execute a global transition
--- @param idTransition identifier from transition
function FiniteStateMachine:doGlobalTransition(idTransition)
  self:doTransition(idTransition,'Global')
end


function FiniteStateMachine:doTransition(idTransition,fromStage)
  print("[DEBUG]FSM - DOING GLOBAL TRANSITION","ID:"..idTransition,"FROM:",fromStage,self.state_transition_table[fromStage][idTransition])
  self.current_stage:hide()
  self:changeStageTo(self.state_transition_table[fromStage][idTransition]())
  self.current_stage:show()
  Engine:render()
end
