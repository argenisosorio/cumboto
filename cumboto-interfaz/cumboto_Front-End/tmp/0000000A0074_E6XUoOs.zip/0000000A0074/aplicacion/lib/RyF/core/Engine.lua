--- Module Engine
module ('Engine', package.seeall)

Engine = {
  load_timer             = nil,
  load_finish_event      = nil,
  widgets_to_load_index  = 1,
  widgets_to_load        = nil,
  render_pipe            = nil,
  widgets                = nil,
  canvas_width           = 0,
  canvas_height          = 0,
  SHOWONADD              = 3,
  LOADONADD              = 2,
  LOADONCHANGE           = 1,
  GINGA2                 = false
}

_G.Engine      = Engine

--- Module initialization method
function Engine:Init()
  print("[DEBUG]ENGINE - INIT")
  self.load_finish_event = SimpleEvent:new()
  self.load_timer        = Timer:new(25)
  self.widgets_to_load   = {}
  self.widgets           = {}
  self.render_pipe       = {}
  self.canvas            = canvas
  self.rendering         = false
  self.memory_used       = 0
  self.canvas_width,self.canvas_height = self.canvas:attrSize()
  self.load_timer.timer_event:addListener(self.loadWidgets,self)
  self.load_finish_event:addListener(self.show,self)
end

--- This method starts the render process. First it loads the widgets on the load queue and then draws all the ones on the render queue
function Engine:render()
  if not self.rendering then
    self.rendering = true
    print("[DEBUG]ENGINE - START LOADING WIDGETS. TO LOAD: " .. #self.widgets_to_load)
    EventManager:disableKeys()
    self:loadWidgets()
  end
end

--- Set compabitily with Ginga 2.0. Sets all the compatibility methods to use Ginga 1.2- working native functions or Ginga 2.0 working native functions
-- @param aBoolean boolean
function Engine:setGinga2Compatibility(aBoolean)
  self.GINGA2 = aBoolean
end

--- Render queue drawing method
function Engine:show()
  print ("[DEBUG]ENGINE - DRAWING. TO DRAW: "..#self.render_pipe)
  for i,w in ipairs(self.render_pipe) do
    w:draw()
    w.in_render_queue = false
    w.has_changed = false
  end
  self.render_pipe = {}
  print ("[DEBUG]ENGINE - ENDED DRAW")
  print ("[DEBUG]ENGINE - MEMORY USED: ".. self.memory_used)
  self.canvas:flush()
  self.rendering = false
  EventManager:enableKeys()
end

--- Set the position of Animation
-- @param loadAnim boolean
-- @param animPos number (1,2,3,4,5)
-- @param images table of canvas
function Engine:setLoadAnim(loadAnim,animPos,images)
  print("[DEBUG]ENGINE - SETING LOADANIMATION:",loadAnim)
  self.loadAnim = loadAnim
  if (self.loadAnim) then
    if (LoadingAnimation ~= nil) then
      LoadingAnimation.setAnimPos(animPos);
	  if (images) then 
	    LoadingAnimation.setImages(images)
	  end
      print("[DEBUG]ENGINE - ANIMATION ORIENT:"..animPos)
	else
	  print("[DEBUG]ENGINE - LOADING ANIMATION NOT IMPORTED")
	  self.loadAnim = false
	end
  end
end

--- Set the position of Animation in coordinates
-- @param posX number
-- @param posY number
function Engine:setFixedLoadAnim(posX,posY)
  print("[DEBUG]ENGINE - SETING FIXED LOADANIMATION:")
  self.loadAnim = true
  if (LoadingAnimation ~= nil) then 
    LoadingAnimation.setFixedAnimPos(posX,posY)
    print("[DEBUG]ENGINE - ANIMATION FIXED POS:"..posX..","..posY)
  else
    print("[DEBUG]ENGINE - LOADING ANIMATION NOT IMPORTED")
    self.loadAnim = false
  end
end

--- Clear screen with any change
-- @param clearOnChange boolean
function Engine:setClearOnChange(clearOnChange)
  print("[DEBUG]ENGINE - SETING CLERONCHANGE:",clearOnChange)
  self.clearOnChange = clearOnChange
end

function Engine:getClearOnChange()
  return self.clearOnChange
end

--- Method that widgets use to report that they have changed
-- @param aWidget Widget Object.
function Engine:changed(aWidget)
  if aWidget.has_changed then return; end
  print("[DEBUG]ENGINE - WIDGET CHANGED", aWidget)
  if (self.clearOnChange and aWidget.is_loaded) then 
    Tools:clear(self.canvas,aWidget:getBounds())
  end
  if aWidget:getVisible() == false then 
    return 
  end
  if (not aWidget.is_loaded) and (not aWidget.in_load_queue) then
    print("[DEBUG]ENGINE - ADDED TO LOAD QUEUE")
    table.insert(self.widgets_to_load,aWidget);
    aWidget.in_load_queue = true
  end
  aWidget.has_changed = true
  if (not aWidget.in_render_queue) then
    print("[DEBUG]ENGINE - ADDED TO RENDER QUEUE")
    table.insert(self.render_pipe,aWidget)
    aWidget.in_render_queue = true
  end
end

--- Method to add a widget to the Engine
-- @param id identifier.
-- @param aWidget Widget Object.
-- @param mode this parameter indicates whether the widget to add will be loaded and composed, only loaded or the engine must wait until the widget is changed. It uses one of three constants: Engine.SHOWONADD, Engine.LOADONADD or Engine.LOADONCHANGE. If it is skipped the default is SHOWONADD
function Engine:addWidget(id, aWidget, mode, store)
  if self.widgets[id] ~= nil then 
     self:removeWidget(id)
  end
  if store==nil then 
    store=true
  end
  print("[DEBUG]ENGINE - ADDING WIDGET","ID: " .. id, aWidget, "MODE: " .. mode, "Store:", store)
  aWidget:setContainer(self,store)
  if ((not aWidget.is_loaded)and (not aWidget.in_load_queue)) and mode >= Engine.LOADONADD then
    print("[DEBUG]ENGINE - ADDED TO LOAD QUEUE")
    table.insert(self.widgets_to_load,aWidget);
    aWidget.in_load_queue = true
  end
  if mode==Engine.SHOWONADD and (not aWidget.in_render_queue) then
    print("[DEBUG]ENGINE - ADDED TO RENDER QUEUE")
    table.insert(self.render_pipe,aWidget) 
    aWidget.in_render_queue = true
  end
  if (store) then
    self.widgets[id] = aWidget
  end
end

--- Wrapper of the "canvas:compose()" native method that the widgets use to compose themselves
-- @param x identifier.
-- @param y Widget Object.
-- @param widgetCanvas widgetCanvas.
function Engine:compose(x,y,widgetCanvas)
  self.canvas:compose(x,y,widgetCanvas)
end

--- Remove widget
-- @param id identifier.
function Engine:removeWidget(id)
  self.widgets[id] = nil
end

--- Get widget
-- @param id identifier.
-- @return Widget Object.
function Engine:getWidget(id)
  if self.widgets[id] == nil then
    print("[DEBUG]ENGINE - WIDGET NOT IN POOL; TRYING TO ADD")
    GlobalWidgetPool:addWidgetToEngine(id)
  end
  return self.widgets[id]
end

--- Load queue loading method
function Engine:loadWidgets()
  if self.widgets_to_load_index <= #self.widgets_to_load then
    if (self.loadAnim and (not LoadingAnimation.isRunning())) then 
      LoadingAnimation.start()
    end
    self.widgets_to_load[self.widgets_to_load_index].load_event:addListener(self.startLoadWidgetTimer,self)
    self.widgets_to_load[self.widgets_to_load_index]:load()
  else
    self:onWidgetLoadEnd()
  end
end

--- Start the timer to load the next widget.
function Engine:startLoadWidgetTimer(sender)
  print("[DEBUG]ENGINE - WIDGET LOADED", sender)
  sender.load_event:removeListener(self.startLoadWidgetTimer,self)
  sender.in_load_queue = false
  self.memory_used = self.memory_used + sender:memoryUsage()
  LoadingAnimation.update(self.widgets_to_load_index/ #self.widgets_to_load)
  self.widgets_to_load_index = self.widgets_to_load_index+1
  self.load_timer:startTimer()
end

--- Dispatch an event when the Engine has finished loading widgets
function Engine:onWidgetLoadEnd()
  print("[DEBUG]ENGINE - ENDED LOADING WIDGETS")
  self.widgets_to_load = {}
  self.widgets_to_load_index = 1
  if (self.loadAnim and LoadingAnimation.isRunning()) then 
    LoadingAnimation.stop()
  end
  self.load_finish_event:dispatch(self)
end