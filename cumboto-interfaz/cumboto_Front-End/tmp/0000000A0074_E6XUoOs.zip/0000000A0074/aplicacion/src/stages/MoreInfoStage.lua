module ('MoreInfoStage', package.seeall)

MoreInfoStage = {

}
setmetatable(MoreInfoStage,Stage)
MoreInfoStage.super   = Stage
MoreInfoStage.__index = MoreInfoStage  --Se prepara para ser Heredada
_G.MoreInfoStage      = MoreInfoStage

function MoreInfoStage:Init()
  print('[DEBUG]{MoreInfoStage} - INIT')
  self.super.Init(self)
  --Instance Atributes Initialization
end

--Instance Methods
function MoreInfoStage:show()
  print('[DEBUG]{MoreInfoStage}-SHOW')
  Engine:getWidget("MainBackground"):setVisible(true)
  Engine:getWidget("MoreInfoText"):setVisible(true)
  Engine:getWidget("Menu3"):setVisible(true)
end

function MoreInfoStage:hide()
  print('[DEBUG]{MoreInfoStage}-HIDE')
end

function MoreInfoStage:number1Pressed()
  FiniteStateMachine:doGlobalTransition("ToMain")
end

function MoreInfoStage:number2Pressed()
  FiniteStateMachine:doGlobalTransition("ToPrevent")
end

function MoreInfoStage:number3Pressed()
end

function MoreInfoStage:number4Pressed()
end