module ('PreventStage', package.seeall)

PreventStage = {

}
setmetatable(PreventStage,Stage)
PreventStage.super   = Stage
PreventStage.__index = PreventStage  --Se prepara para ser Heredada
_G.PreventStage      = PreventStage

function PreventStage:Init()
  print('[DEBUG]{RedStage} - INIT')
  self.super.Init(self)
  --Instance Atributes Initialization
  
end

--Instance Methods
function PreventStage:show()
  print('[DEBUG]{PreventStage}(Display)-SHOW')
  Engine:getWidget("MainBackground"):setVisible(true)
  Engine:getWidget("PreventText"):setVisible(true)
  Engine:getWidget("Menu2"):setVisible(true)  
end

function PreventStage:hide()
  print('[DEBUG]{PreventStage}(Display)-HIDE')
end

function PreventStage:number1Pressed()
  FiniteStateMachine:doGlobalTransition("ToMain")
end

function PreventStage:number2Pressed()
end

function PreventStage:number3Pressed()
  FiniteStateMachine:doGlobalTransition("ToMoreInfo")
end

function PreventStage:number4Pressed()
end