module ('MainStage', package.seeall)

MainStage = {

}
setmetatable(MainStage,Stage)
MainStage.super   = Stage
MainStage.__index = MainStage  --Se prepara para ser Heredada
_G.MainStage      = MainStage

function MainStage:Init()
  print('[DEBUG]{MainStage} - INIT')
  self.super.Init(self)
  --Instance Atributes Initialization
  Engine:getWidget("MainBackground"):setVisible(true)
  Engine:getWidget("Menu1"):setVisible(true)
end

--Instance Methods
function MainStage:show()
  print('[DEBUG]{MainStage}(Display)-SHOW')
  Engine:getWidget("MainBackground"):setVisible(true)
  Engine:getWidget("Menu1"):setVisible(true)
end

function MainStage:hide()
  print('[DEBUG]{MainStage}(Display)-HIDE')
end

function MainStage:enterPressed()
  print('[DEBUG]{MainStage}(KeyEvent)-ENTER')
end

function MainStage:number1Pressed()
end

function MainStage:number2Pressed()
  FiniteStateMachine:doGlobalTransition("ToPrevent")
end

function MainStage:number3Pressed()
  FiniteStateMachine:doGlobalTransition("ToMoreInfo")
end

function MainStage:number4Pressed()
end