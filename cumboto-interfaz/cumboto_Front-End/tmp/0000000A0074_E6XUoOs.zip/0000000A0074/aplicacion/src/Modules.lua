--Framework libs

--load Core
require 'lib.RyF.core.Object'
require 'lib.RyF.core.FiniteStateMachine'
require 'lib.RyF.core.Stage'
require 'lib.RyF.core.Engine'
require 'src.GlobalWidgetPool'

-- load Events
require 'lib.RyF.events.SimpleEvent'
require 'lib.RyF.events.Timer'
require 'lib.RyF.events.EventManager'

--load Widgets
require 'lib.RyF.widgets.Widget'
require 'lib.RyF.widgets.Image'
require 'lib.RyF.widgets.Text'
require 'lib.RyF.widgets.WidgetContainer'

--load Tools
require 'lib.RyF.tools.Tools'
require 'lib.RyF.tools.LoadingAnimation'

------------*--------------------------


--- USER LIBS, WIDGETS, TOOLS AND STAGES

--user Widgets
--user Tools
--user Stages
require 'src.stages.MainStage'
require 'src.stages.PreventStage'
require 'src.stages.MoreInfoStage'

