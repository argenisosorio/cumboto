
function loadStages()

  local main   = MainStage:new()
  local prevent = PreventStage:new()
  local moreInfo = MoreInfoStage:new()

  FiniteStateMachine:addGlobalTransition("ToPrevent",prevent)
  FiniteStateMachine:addGlobalTransition("ToMoreInfo",moreInfo)
  FiniteStateMachine:addGlobalTransition("ToMain",main)
  FiniteStateMachine:setInitialStage(main)
  
end