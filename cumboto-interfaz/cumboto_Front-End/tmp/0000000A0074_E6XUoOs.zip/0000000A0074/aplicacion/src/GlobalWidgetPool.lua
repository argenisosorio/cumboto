module ('GlobalWidgetPool', package.seeall)
GlobalWidgetPool = {}
_G.GlobalWidgetPool      = GlobalWidgetPool

function GlobalWidgetPool:Init()
  self.usableWidgetsPool = {}
  self:assembleUsablePool()
  self:autoLoadWidgets()
end;

--FUNCTION CALLED BY THE ENGINE TO LOAD THE MISSING WIDGET
--HAVE IN MIND THAT THIS WIDGET HASNT WENT THROUGH THE LOAD/RENDER CICLE
function GlobalWidgetPool:addWidgetToEngine(id)
  if self.usableWidgetsPool[id] ~= nil then
    local w = self.usableWidgetsPool[id]()
 Engine:addWidget(id,w,Engine.LOADONADD)
  end
end

--USED TO PREPARE THE LOAD OF POSIBLE USABLE WIDGETS
function GlobalWidgetPool:assembleUsablePool()

end

-- USED TO AUTO LOAD WIDGETS THAT WILL BE USED
-- ITS CALLED BEFORE ANY STAGE:INIT()
function GlobalWidgetPool:autoLoadWidgets()
 Engine:addWidget("MainBackground", Image:new(0,0,"resources/images/Dengue1.jpg"),Engine.LOADONADD)
 Engine:addWidget("PreventText", Image:new(114,172,"resources/images/Dengue2.jpg"),Engine.LOADONADD)
 Engine:addWidget("MoreInfoText", Image:new(114,172,"resources/images/Dengue3.jpg"),Engine.LOADONADD)
 
 Engine:addWidget("Menu1", Image:new(129,131,"resources/images/Menu1-QueEs.jpg"),Engine.LOADONADD)
 Engine:addWidget("Menu2", Image:new(230,131,"resources/images/Menu2-Prevencion.jpg"),Engine.LOADONADD)
 Engine:addWidget("Menu3", Image:new(347,131,"resources/images/Menu3-MasInfo.jpg"),Engine.LOADONADD) 
end