-- Framework set Options (Engine)
function configFramework() 
 Engine:setClearOnChange(false)
 Engine:setLoadAnim(true,5)
 Engine:setGinga2Compatibility(false)
 GlobalWidgetPool:Init()
end