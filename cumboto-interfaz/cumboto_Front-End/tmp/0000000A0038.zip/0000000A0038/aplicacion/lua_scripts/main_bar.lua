local DX, DY = canvas:attrSize()


local LEFT_SPEED = 2
local TIME_SPEED = 50

-- Valores para el stado del tiempo
local marquee_state_ini = DX
local marquee_state_fin = 0
local marquee_state_y = 41
local marquee_state_tmp 
local marquee_state_long_tmp 
local marquee_state_long = DX

--Valores para sismos
local marquee_quakes_ini = DX
local marquee_quakes_fin = 0
local marquee_quakes_y = 41
local marquee_quakes_tmp 
local marquee_quakes_long_tmp 
local marquee_quakes_long = DX


local info
local state
local quakes = ""
local marquee = 1

canvas:attrFont("Tiresias-Bold", 16)

function read_Info()
       
    local json = require("json")
    local data = require("data")
        
    info = json.decode(data.INF)
    
    state = info.inf.inameh[1]
    marquee_state_tmp = state
    local txtLarg, txtAlt = canvas:measureText(state)
    marquee_state_long = marquee_state_long + txtLarg
    marquee_state_long_tmp = marquee_state_long

    for i = 1, #info.inf.funvisis, 1 do
         if quakes:len() ~= 0 then
            quakes = quakes.."     ::     "..info.inf.funvisis[i]
        else
            quakes = info.inf.funvisis[i]
        end
    end

    
    marquee_quakes_tmp = quakes
    local txtLarg, txtAlt = canvas:measureText(quakes)
    marquee_quakes_long = marquee_quakes_long + txtLarg
    marquee_quakes_long_tmp = marquee_quakes_long
    
    
end

-- funcion para dibujar

function refresh_bar()
    
    if marquee == 1 then
        if marquee_state_long_tmp >= 0 then
            marquee_state_ini = marquee_state_ini - LEFT_SPEED
            marquee_state_long_tmp = marquee_state_long_tmp - LEFT_SPEED
        else
            marquee_state_long_tmp = marquee_state_long
            marquee_state_tmp = state
            marquee_state_ini = DX
            marquee = 2
            event.post ('out',{ class='ncl', type='presentation', label='stop_time', action='start' })
            event.post ('out',{ class='ncl', type='presentation', label='start_time', action='stop' })
        end
    end
    
    if marquee == 2 then
        if marquee_quakes_long_tmp >= 0 then
            marquee_quakes_ini = marquee_quakes_ini - LEFT_SPEED
            marquee_quakes_long_tmp = marquee_quakes_long_tmp - LEFT_SPEED
        else
            marquee_quakes_long_tmp = marquee_quakes_long
            marquee_quakes_tmp = quakes
            marquee_quakes_ini = DX
            marquee = 1
            event.post ('out',{ class='ncl', type='presentation', label='start_time', action='start' })
            event.post ('out',{ class='ncl', type='presentation', label='stop_time', action='stop' })
        end
    end
    
    
    canvas:attrColor(0,0,0,0)
    canvas:clear (0,0, DX , DY)
    
    canvas:attrColor(255,255,255,255)
    
    if marquee == 1 then
        canvas:drawText(marquee_state_ini, marquee_state_y, marquee_state_tmp)
    end
    
    if marquee == 2 then
        canvas:drawText(marquee_quakes_ini, marquee_quakes_y, marquee_quakes_tmp)
    end

    canvas:flush()
    
    
    --dispara el evento de tiempo despues de 50 segundos
    event.timer(TIME_SPEED, function()
        event.post ('in', { class='user', time=event.uptime () })
    end)
    
    
end



-- funcion principal ue captura los eventos
function handler_bar(evt)


    if evt.class ~= 'user' then return end

    --si es un evento de tiempo se ejecuta la función para redibujar
    if evt.class == 'user' and evt.time ~= nil then
        refresh_bar()
    end
    --canvas:compose(0, 0, canvas:new("../theme/bar_info.png"))
    
    
    
end

--registra la funcion principal
read_Info()
event.register(handler_bar)
refresh_bar()




