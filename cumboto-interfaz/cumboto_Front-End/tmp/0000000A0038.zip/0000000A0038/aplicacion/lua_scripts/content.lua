module("content")

CONTENT = [[{
  "content": {
    "blue": {
      "contacts": "../media/blue_contacts.png", 
      "quakes": [
        "../media/blue_quake_1.png", 
        "../media/blue_quake_2.png", 
        "../media/blue_quake_3.png", 
        "../media/blue_quake_4.png", 
        "../media/blue_quake_5.png"
      ], 
      "zone": [
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_1.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_2.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_3.png"
        ], 
        [
          "../theme/time_icons/nublado_precipitaciones.png", 
          "../media/blue_zone_4.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_5.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_6.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_7.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_8.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_9.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_10.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_11.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_12.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_13.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_14.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_15.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_16.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_17.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_18.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_19.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_20.png"
        ], 
        [
          "../theme/time_icons/nublado.png", 
          "../media/blue_zone_21.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_22.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_23.png"
        ], 
        [
          "../theme/time_icons/ninguno.png", 
          "../media/blue_zone_24.png"
        ], 
        [
          "../theme/time_icons/parc_nub_sol.png", 
          "../media/blue_zone_25.png"
        ]
      ], 
      "title": "../media/blue_title.png"
    }, 
    "green": {
      "text": [
        "../media/green_1.png"
      ], 
      "image": [
        "../media/Texto-13-Imagen-1-Pantalla-Unica-H.jpg"
      ], 
      "image_source": [
        "../media/source_image_green_1.png"
      ], 
      "title": "../media/green_title.png"
    }, 
    "yellow": {
      "text": [
        "../media/yellow_1.png"
      ], 
      "image": [
        "../media/Texto-13-Imagen-1-Pantalla-Unica-HA.jpg"
      ], 
      "image_source": [
        "../media/source_image_yellow_1.png"
      ], 
      "title": "../media/yellow_title.png"
    }, 
    "red": {
      "text": [
        "../media/red_1.png"
      ], 
      "image": [
        "../media/Evento-13-Imagen-1-Pantalla-Unica-H.jpg"
      ], 
      "image_source": [
        "../media/source_image_red_1.png"
      ], 
      "title": "../media/red_title.png"
    }
  }
}]]
