module("data")

INF = [[{
  "inf": {
    "inameh": [
      "21/10/2016 11:46AM - Precipitaciones dispersas sobre regiones:  Andes, Zuliana y Centro Occidental."
    ], 
    "funvisis": [
      "21/10/2016 06:18AM - Magnitud: 3.7, Ubicación: 15 Km al oeste de Guiria", 
      "21/10/2016 01:05AM - Magnitud: 3.3, Ubicación: 12 Km al norte de Guiria", 
      "03/11/2013 05:19PM - Magnitud: 3.5, Ubicación: 60 Km al noreste de Machiques", 
      "03/11/2013 12:11PM - Magnitud: 3.0, Ubicación: 55 Km al noreste de Bachaquero", 
      "03/11/2013 10:54AM - Magnitud: 4.1, Ubicación: 60 Km al sureste de Guiria", 
      "26/10/2013 05:51AM - Magnitud: 3.0, Ubicación: 2 Km al suroeste de Valencia", 
      "19/10/2013 06:17AM - Magnitud: 3.0, Ubicación: 40 Km al noreste de Guiria", 
      "18/10/2013 03:00AM - Magnitud: 3.5, Ubicación: 15 Km al norte de Merida", 
      "17/10/2013 11:28PM - Magnitud: 3.1, Ubicación: 17 Km al norte de Merida", 
      "17/10/2013 11:19PM - Magnitud: 3.5, Ubicación: 19 Km al noreste de Merida"
    ]
  }
}]]
