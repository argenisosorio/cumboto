--[[
__autor__   = "Alexander Olivares (aox)"
__email__   = "olivaresa@gmail.com"
__date__    = "2012-07-17"
__version__ = "beta-0.1"
__license__ = "GPLv2"
]]

-- almacena la tecla presionada
local category_color

--define las teclas 
local keys = {RED="red", GREEN="green", YELLOW="yellow", BLUE="blue",
            F1="red", F2="green", F3="yellow", F4="blue"}

-- variable para el contenido
local content

local content_spec = { red = {bk = "../theme/background_red.png", l = "../theme/left_arrow_red.png", r = "../theme/right_arrow_red.png", count = 0, current = 1},
                  green = {bk = "../theme/background_green.png", l = "../theme/left_arrow_green.png", r = "../theme/right_arrow_green.png", count = 0, current = 1},
                  yellow = {bk = "../theme/background_yellow.png", l = "../theme/left_arrow_yellow.png", r = "../theme/right_arrow_yellow.png", count = 0, current = 1},
                  blue = {bk = "../theme/background_blue.png", l = "../theme/left_arrow_blue.png", r = "../theme/right_arrow_blue.png", u = "../theme/up_arrow_blue.png", d = "../theme/down_arrow_blue.png" , count_lr = 0, current_lr = 1, count_ud = 0, current_ud = 1}
                }

-- funcion para leer la informacion de contenido
function read_Content()
       
    local json = require("json")
    content = require("content")
        
    content = json.decode(content.CONTENT)
    
    
    content_spec.red.count = #content.content.red.text
    content_spec.green.count = #content.content.green.text
    content_spec.yellow.count = #content.content.yellow.text
    content_spec.blue.count_ud = #content.content.blue.quakes
    content_spec.blue.count_lr = 7
end

-- funcion para evaluar la tecla presionada 
function set_key_option(color, left, right, up, down)
    
    canvas:attrColor(0,0,0,0)
    canvas:clear (0, 0, 720 , 576)
    
    
    -- dibuja background del color
    canvas:compose(0,0, canvas:new(content_spec[color].bk))

    
    if color ~= "blue" then
        
        --Verifica tecla derecha y actualiza el item
        if right == true and content_spec[color].count >= (content_spec[color].current + 1) then
            content_spec[color].current = content_spec[color].current + 1
        end

        --Verifica tecla izquierda y actualiza el item
        if left == true and 1 <= (content_spec[color].current - 1)then
            content_spec[color].current = content_spec[color].current - 1
        end

        -- dibuja flecha derecha
        if content_spec[color].count > content_spec[color].current then
            canvas:compose(546,334, canvas:new(content_spec[color].r))
        end

        -- dibuja flecha izquierda
        if 1 < content_spec[color].current then
            canvas:compose(24,334, canvas:new(content_spec[color].l))
        end
        
        --imagen texto titulo
        canvas:compose(190, 56, canvas:new(content.content[color].title))

        --imagen de texto
        canvas:compose(52, 110, canvas:new(content.content[color].text[content_spec[color].current]))
        
        --imagen de noticia
        canvas:compose(530.51, 164, canvas:new(content.content[color].image[content_spec[color].current]))    

        --fuente imagen de noticia
        canvas:compose(540, 278, canvas:new(content.content[color].image_source[content_spec[color].current]))    
        
        canvas:flush()

    end
    
    if color == "blue" then
        
        --TECLAS down o up
        --Verifica tecla derecha y actualiza el item
        if down == true and content_spec[color].count_ud >= (content_spec[color].current_ud + 1) then
            content_spec[color].current_ud = content_spec[color].current_ud + 1
        end

        --Verifica tecla izquierda y actualiza el item
        if up == true and 1 <= (content_spec[color].current_ud - 1)then
            content_spec[color].current_ud = content_spec[color].current_ud - 1
        end

        -- dibuja flecha abajo
        if content_spec[color].count_ud > content_spec[color].current_ud then
            canvas:compose(676,400, canvas:new(content_spec[color].d))
        end

        -- dibuja flecha arriba
        if 1 < content_spec[color].current_ud then
            canvas:compose(676,170, canvas:new(content_spec[color].u))
        end
        
        --imagen de texto sismos
        canvas:compose(362, 174, canvas:new(content.content[color].quakes[content_spec[color].current_ud]))
            
        --TECLAS left o down

        if right == true and content_spec[color].count_lr >= (content_spec[color].current_lr + 1) then
            content_spec[color].current_lr = content_spec[color].current_lr + 1
            zone_end = content_spec[color].current_lr * 4
            zone_ini = zone_end - 3
        end

        --Verifica tecla izquierda y actualiza el item
        if left == true and 1 <= (content_spec[color].current_lr - 1)then
            content_spec[color].current_lr = content_spec[color].current_lr - 1
            zone_end = (content_spec[color].current_lr * 4) 
            zone_ini = zone_end - 3
        end

        -- dibuja flecha derecha
        if content_spec[color].count_lr > content_spec[color].current_lr then
            canvas:compose(324,407, canvas:new(content_spec[color].r))
        end

        -- dibuja flecha izquierda
        if 1 < content_spec[color].current_lr then
            canvas:compose(32,407, canvas:new(content_spec[color].l))
        end
        

       
        --imagen de texto sismos
        --canvas:compose(386, 186, canvas:new(content.content[color].zone[1]))

        zone_control = 1
        for zone_img = zone_ini, zone_end do
            
            
            --print(content.content[color].zone[zone_img][1])

            if zone_control == 1 then
                add_x = 0
                add_y = 0
            elseif zone_control == 2 then
                add_x = 100
                add_y = 60
            elseif zone_control == 3 then
                add_x = 0
                add_y = 66+60
            elseif zone_control == 4 then
                add_x = 100
                add_y = 66+60+60
            end
            
            --[[
            if zone_control == 1 then
                add_x = 0
                add_y = 0
            elseif zone_control == 2 then
                add_x = 160
                add_y = 0
            elseif zone_control == 3 then
                add_x = 0
                add_y = 66
            elseif zone_control == 4 then
                add_x = 160
                add_y = 66
            end            
            ]]
            
            if content.content[color].zone[zone_img] then
                canvas:compose(85 + add_x -60, 120 + add_y + 20, canvas:new(content.content[color].zone[zone_img][1]))
                canvas:compose(85 + add_x, 120 + add_y, canvas:new(content.content[color].zone[zone_img][2]))
                zone_control = zone_control +1
            end
            
            
        end
        
        --imagen texto titulo
        --canvas:compose(190, 56, canvas:new(content.content[color].title))
        
        --imagen texto de contactos
        canvas:compose(130, 430, canvas:new(content.content[color].contacts))
        
        canvas:flush()


        
    end
end

-- funcion principal ue captura los eventos
function handler(evt)
    
    if evt.class ~= 'key' then return end
    
    if evt.class == 'key' and  evt.type == 'press' then 

        local key = evt.key

        -- examina si fue presionada la tecla izquierda o derecha
        if key == "CURSOR_LEFT" then
            
            -- ejecuta la funcion para examniar que tecla fue presionada
            set_key_option(category_color, true, false, false, false)
            
        end 

        if key == "CURSOR_RIGHT" then

            -- ejecuta la funcion para examniar que tecla fue presionada
            set_key_option(category_color, false, true, false, false)
        end 

        -- examina si fue presionada la tecla arriba o abajo
        if key == "CURSOR_UP" then
            
            -- ejecuta la funcion para examniar que tecla fue presionada
            set_key_option(category_color, false, false, true, false)
            
        end 

        -- examina si fue presionada la tecla arriba o abajo
        if key == "CURSOR_DOWN" then
            
            -- ejecuta la funcion para examniar que tecla fue presionada
            set_key_option(category_color, false, false, false, true)
            
        end 

            
        if keys[key] then
            --almacena la tecla presionada en minuscula
            lower_key = keys[key]
            
            -- ejecuta la funcion para examniar que tecla fue presionada
            set_key_option(lower_key, true, true, true, true)
            
            -- almacena el color
            category_color = lower_key
        end 
    end
    
    
end

--registra la funcion principal
event.register(handler)
read_Content()
category_color = "red"
set_key_option(category_color)




