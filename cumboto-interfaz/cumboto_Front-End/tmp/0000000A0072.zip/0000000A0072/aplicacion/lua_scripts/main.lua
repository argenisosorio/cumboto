--[[
__autor__   = "Alexander Olivares (aox)"
__email__   = "olivaresa@gmail.com"
__date__    = "2012-10-25"
__version__ = "beta-0.1"
__license__ = "GPLv2"
]]

local category_color
local current_item

local keys = {RED="red", GREEN="green", YELLOW="yellow", BLUE="blue",
            F1="red", F2="green", F3="yellow", F4="blue"}

--funcion para texto
function breakString(str, maxLineSize)
  local t = {}
  local i, fim, countLns = 1, 0, 0

  if (str == nil) or (str == "") then
     return t
  end 

  --str = string.gsub(str, "\n", " ")
  --str = string.gsub(str, "\r", " ")
    
  while i < #str do
     countLns = countLns + 1
     if i > #str then
        t[countLns] = str
        i = #str 
     else
        fim = i+maxLineSize-1
        if fim > #str then
           fim = #str
        else

            if string.byte(str, fim) ~= 32 then
               fim = string.find(str, ' ', fim)
               if fim == nil then
                  fim = #str
               end
            end
        end
        
        str_line = string.sub(str, i, fim)
        index_str_n = string.find(str_line, '\n')
        
        if index_str_n then
            fim = i + index_str_n - 1
        end
        
        str_line = string.sub(str, i, fim)
        str_line = string.gsub(str_line, "\n", "")
        str_line = string.gsub(str_line, "\r", "")
        t[countLns]=str_line
        i=fim+1
     end
  end
  
  return t
end


--funcion para pintar texto
function draw_text(x,y,size,text)
        
        canvas:attrFont("Tiresias", size)
        canvas:drawText(screen_p("x",x), screen_p("y", y), text)
end

--funcion para pintar texto parrafo
function draw_par(x,y,size,text,num_chars,y_avance)

    canvas:attrFont("Tiresias", size)
        

    local par = breakString(text, num_chars)
    
    texty = screen_p("y", y)
    
    for k,ln in pairs(par) do
        
        
        texty = texty + screen_p("y",y_avance)
        canvas:drawText(screen_p("x",x), texty, ln)
    end
end

--funcion para pintar imagen
function draw_image(imagename, x, y)
    
    image = canvas:new(imagename)
    canvas:compose(screen_p("x",x), screen_p("y",y), image)

end

--funcion para calcular pixeles a partir de porcentaje
function screen_p(coordenate, percentage)
    
    local dx, dy = canvas:attrSize()
    if coordenate == "x" then
        return percentage * dx / 100
    end

    if coordenate == "y" then
        return percentage * dy / 100
    end
    
end


--funcion para leer datos en format json
function read_Data()
       
    local json = require("json")
    local data = require("data")
        
    alldata = json.decode(data.DATA)

end

--funcion para limpiar la pantalla
function clear_screen(x1,y1,x2,y2)
    canvas:attrColor(0,0,0,0)
    --canvas:drawRect("fill",screen_p("x",x1), screen_p("y",y1), screen_p("x",x2), screen_p("y",y2)) --limpia noticia e imagen
    --canvas:flush()
    canvas:clear(screen_p("x", x1), screen_p("y", y1), screen_p("x", x2), screen_p("y", y2))
end


function red_paint()

    clear_screen(0,0,100,100)
    draw_image("../theme/button_red.png", 15.00, 11.11)
    draw_image("../theme/text_window.png", 42.50, 42.36)
    draw_image("../theme/title_window.png", 18.19, 32.64)
    
    draw_image("../theme/instructor.png", 7.92, 22.57)
    draw_image("../theme/logo_anna_kua.png", 16.39, 25)
    
    draw_image("../theme/paginate_window.png", 90.69, 84)
    draw_image("../theme/img_window.png", 5, 46.35)
    draw_image(alldata.red.image, 6, 48.2)
    
    canvas:attrColor(255,0,0,0)
    draw_text(21, 35, 26, alldata.red.title)
    canvas:attrColor(0,0,0,0)
    

    draw_par(45,40,18,alldata.red.text[current_item],30,4)

    draw_text(91.55, 85.02, 14, current_item.."/"..#alldata.red.text)

    if #alldata.red.text > current_item then
        draw_image("../theme/arrow_r.png", 92.55, 60.59)
    end

    if current_item > 1 then
        draw_image("../theme/arrow_l.png", 40.00, 60.59)
    end
    
    canvas:flush()
    
end


function green_paint()
    clear_screen(0,0,100,100)
    draw_image("../theme/button_green.png", 26, 11.11)
    draw_image("../theme/text_window.png", 42.50, 42.36)
    draw_image("../theme/title_window.png", 18.19, 32.64)
    
    draw_image("../theme/instructor.png", 7.92, 22.57)
    draw_image("../theme/logo_anna_kua.png", 16.39, 25)
    
    draw_image("../theme/paginate_window.png", 90.69, 84)
    draw_image("../theme/img_window.png", 5, 46.35)
    draw_image(alldata.green.image, 6, 48,2)
    
    canvas:attrColor(0,128,0,0)
    draw_text(21, 35, 26, alldata.green.title)
    canvas:attrColor(0,0,0,0)
    

    draw_par(45,40,18,alldata.green.text[current_item],30,4)

    draw_text(91.55, 85.02, 14, current_item.."/"..#alldata.green.text)

    if #alldata.green.text > current_item then
        draw_image("../theme/arrow_r.png", 92.55, 60.59)
    end

    if current_item > 1 then
        draw_image("../theme/arrow_l.png", 40.00, 60.59)
    end
    
    canvas:flush()
    
end

function yellow_paint()
    clear_screen(0,0,100,100)
    draw_image("../theme/button_yellow.png", 37.22, 11.11)
    draw_image("../theme/text_window.png", 42.50, 42.36)
    draw_image("../theme/title_window.png", 18.19, 32.64)
    
    draw_image("../theme/instructor.png", 7.92, 22.57)
    draw_image("../theme/logo_anna_kua.png", 16.39, 25)
    
    draw_image("../theme/paginate_window.png", 90.69, 84)

    draw_image("../theme/img_window.png", 5, 46.35)
    
    --canvas:attrColor(0, 0, 0,0) 
    --canvas:drawRect("fill", 0,0,720,576)    
    draw_image(alldata.yellow.image, 6, 48.2)
    
    canvas:attrColor(225,181,8,0)
    draw_text(21, 35, 26, alldata.yellow.title)
    canvas:attrColor(0,0,0,0)
    

    draw_par(45,40,18,alldata.yellow.text[current_item],30,4)

    draw_text(91.55, 85.02, 14, current_item.."/"..#alldata.yellow.text)

    if #alldata.yellow.text > current_item then
        draw_image("../theme/arrow_r.png", 92.55, 60.59)
    end

    if current_item > 1 then
        draw_image("../theme/arrow_l.png", 40.00, 60.59)
    end
    
    canvas:flush()
    
end

function game_paint()
    clear_screen(0,0,100,100)
    draw_image("../theme/button_blue.png", 48.10, 11.11)
    draw_image("../theme/title_window.png", 18.19, 32.64)
    draw_image("../theme/instructor.png", 7.92, 22.57)
    draw_image("../theme/logo_anna_kua.png", 16.39, 25)
    draw_image("../media/game/window_1.png", 4.86, 45.66)
    draw_image("../media/game/window_2.png", 57.78, 45.66)
    draw_image("../media/game/doll_1.gif", 85.42, 51.56)
    draw_image("../media/game/doll_2.gif", 6.81, 47.74)
    draw_image("../media/game/window_input_letter.png", 19.86, 47.57)
    draw_image("../media/game/window_letter.png", 25, 70.83)
    draw_image("../media/game/timer.gif", 84.17, 73.96)
    
    
    
    canvas:attrColor(0,0,255,0)
    draw_text(21, 35, 26, "Juego")
    
    canvas:attrColor(0,0,0,0)

    draw_text(24.72, 67.19, 18, "¿Qué palabra es?")

    
    canvas:flush()
    
end

function set_key_option(color)
    
    if color == "red" then
        current_item = 1
        red_paint()
    end
    if color == "green" then 
        current_item = 1
        green_paint()

    end
    if color == "yellow" then 
        current_item = 1
        yellow_paint()
    end
    if color == "blue" then
        current_item = 1
        game_paint()
    end
    
    
end

function handler(evt)
    if evt.class ~= 'key' then return end
    if evt.type ~= 'press' then return true end


    if evt.class == 'key' and  evt.type == 'press' then 

        local key = evt.key

        if key == "CURSOR_LEFT" then
            
            if current_item > 1 then
                current_item = current_item - 1
            end

            if category_color == "red" then
                red_paint()
            end

            if category_color == "green" then
                green_paint()
            end
            if category_color == "yellow" then
                yellow_paint()
            end
            
        end 

        if key == "CURSOR_RIGHT" then

                if category_color == "red" and current_item < #alldata.red.text then
                    current_item = current_item + 1
                    red_paint()
                end
                if category_color == "green" and current_item < #alldata.green.text then
                    current_item = current_item + 1
                    green_paint()
                end
                if category_color == "yellow" and current_item < #alldata.yellow.text then
                    current_item = current_item + 1
                    yellow_paint()
                end

        end 
            
        if keys[key] then
            lower_key = keys[key]
            set_key_option(lower_key)
            category_color = lower_key
        end 
    end
end

read_Data()
set_key_option("red")
category_color = "red"
event.register(handler)





