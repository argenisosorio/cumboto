module("data")

DATA=[[{

    "red": {

        "text": [

            "A la tropa de José Tomás Boves se le conocía en 1814 como la Legión Infernal, despiadados guerreros llaneros que peleaban a favor de España por el odio que les había sembrado su comandante en el corazón.",

            "El 12 de febrero de ese año José Félix Ribas se atrincheró en la ciudad de La Victoria dispuesto a enfrentar a la terrible legión, pero como no tenía suficientes soldados solicitó apoyo a los jóvenes seminaristas de los colegios de Caracas quienes se sumaron casi en su totalidad a defender la República independiente.",

            "“He ahí a Boves” les dijo el General Ribas “Con un ejército cinco veces más grande que el nuestro, y aún así me parece poco”.",
            
            "Ribas con su ejército de jóvenes combatientes resistió la embestida realista durante 9 horas, hasta la llegada heroica del capitán Vicente Campo Elías, quien con una tropa de 200 andinos terminó inclinando la balanza a favor de la República.",
            
            "Las palabras con las que Ribas ensalzara ese día los corazones de sus muchachos, con el tiempo se convirtieron en leyenda: “No podemos optar entre vencer o morir: ¡Necesario es vencer!”."

        ],

        "image": "../media/image_1.jpg",

        "title": "Batalla de la Victoria"

    },
    "green": {

        "text": [

            "Fue un ilustre militar venezolano nacido en Caracas el 19 de septiembre de 1775. Hijo de la oligarquía criolla, abandonó, como Bolívar, todas sus posesiones para unirse a la causa patriota.",

            "Ribas fue también seminarista, conociendo desde adentro las inquietudes de los jóvenes de finales del Siglo XVIII y principios del XIX. Fue también agricultor y por sobre todas las cosas un radical defensor de la independencia.",

            "Participó en la Junta Suprema durante la Primera República y acompañó a Bolívar en su exilio a Nueva Granada. Se unió a la causa libertadora, liderando importantes batallas en  Niquitao, Los Horcones y La Victoria.",
            
            "Fue capturado y asesinado mediante el suplicio por los realistas en 1815."
        ],

        "image": "../media/image_2.jpg",

        "title": "José Félix Ribas"

    },
    "yellow": {

        "text": [

            "Quizás te preguntes por qué un grupo de jóvenes aspirantes a sacerdote, sin ninguna obligación militar, abandonaría la seguridad del seminario para unirse a la causa patriota. \nMuchos historiadores afirman que la elocuencia del discurso de Ribas, un antiguo compañero seminarista, fue suficiente para convencerlos.",

            "Lo que pocos saben, es que en las viejas bibliotecas del seminario Santa Rosa de Lima de la ciudad de Caracas, había muchos libros clandestinos traídos desde Europa. Eran clandestinos porque contenían novísimas ideas revolucionarias sobre libertad, igualdad y fraternidad.",

            "En ellos, se ponía de manifiesto la ilegitimidad del régimen realista y se advertía la necesidad de generar una forma de gobierno moderna. Eran los mismos libros que inspiraron las acciones del Libertador, de Simón Rodríguez y Andrés Bello.",
            
            "Y fue así como en el interior del seminario, tras sigilosas lecturas nocturnas, los corazones revolucionados de los jóvenes seminaristas comprometieron su vida en la Independencia de la Patria. No recordamos sus nombres, pero no olvidamos su heroísmo, compromiso y lealtad con la historia."
        ],

        "image": "../media/image_3.jpg",

        "title": "El Seminario"

    },
    

}]]
